
import argparse
import sys
import logging
import json
import csv
from pathlib import Path
from typing import List

from .config import load_config, Strategies
from .utils.logging import setup_logging
from .core.workflow import CopyBlockWorkflow

from .utils.mocks import apply_mocks

def _load_item_types(config):
    """Helper to load item types from config path."""
    item_types = []
    it_path = config.get('data_paths', {}).get('item_types')
    if it_path:
        path_obj = Path(it_path)
        if path_obj.exists():
            try:
                with open(path_obj, 'r') as f:
                    item_types = json.load(f)
            except Exception as e:
                logging.warning(f"Failed to parse item types from {it_path}: {e}")
        else:
            logging.warning(f"Item types file not found at: {it_path}")
    return item_types

def run_single_keyword(args):
    """Run pipeline for a single keyword."""
    config = load_config(args.config)
    setup_logging(args.log_dir)
    
    keyword = args.keyword
    mode = args.mode
    
    print(f"Processing keyword: {keyword} [Mode: {mode}]")
    
    if args.mock:
        apply_mocks()

    # Load item types
    item_types = _load_item_types(config)

    # Run Workflow
    workflow = CopyBlockWorkflow(config, mode=mode)
    
    result = workflow.run(query=keyword, item_types=item_types)
    
    # Output
    print(json.dumps(result, indent=2))
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2)
            print(f"Result saved to {args.output}")

def run_batch(args):
    """Run pipeline for a batch of keywords."""
    config = load_config(args.config)
    setup_logging(args.log_dir)
    
    if args.mock:
        apply_mocks()
    
    # Read inputs
    keywords = []
    if args.input_file.endswith('.csv'):
        with open(args.input_file, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            # Basic header skip logic
            rows = list(reader)
            if rows and rows[0][0].lower() in ['keyword', 'query']:
                rows = rows[1:]
            keywords = [r[0] for r in rows if r]
    else:
         with open(args.input_file, 'r', encoding='utf-8') as f:
            keywords = [line.strip() for line in f if line.strip()]

    # Load item types once
    item_types = _load_item_types(config)
            
    print(f"Starting batch processing for {len(keywords)} keywords [Mode: {args.mode}]...")
    
    results = []
    for i, kw in enumerate(keywords, 1):
        print(f"[{i}/{len(keywords)}] {kw}")
        try:
            workflow = CopyBlockWorkflow(config, mode=args.mode)
            
            res = workflow.run(query=kw, item_types=item_types)
            
            # Extract fanouts list for CSV
            fanout_out = res.get("fanout_output", {})
            fanouts_data = fanout_out.get("fanouts", [])
            fanouts_str = json.dumps(fanouts_data)
            
            # Extract reasoning from various possible keys
            reasoning = (
                fanout_out.get("reasoning") or 
                fanout_out.get("brainstorming_process") or 
                fanout_out.get("validation_logic") or 
                ""
            )
            
            results.append({
                "keyword": kw, 
                "copy": res.get("final_copy"),
                "fanouts": fanouts_str,
                "reasoning": reasoning,
                "time": res.get("total_time")
            })
        except Exception as e:
            logging.error(f"Failed {kw}: {e}")
            results.append({"keyword": kw, "error": str(e)})

    # Save
    if args.output_file:
        keys = ["keyword", "copy", "fanouts", "reasoning", "time", "error"]
        with open(args.output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(results)
        print(f"Batch results saved to {args.output_file}")


def main():
    parser = argparse.ArgumentParser(prog="copy_gen", description="Copy Block Generator CLI")
    parser.add_argument("--config", default="conf.yml", help="Path to config file")
    parser.add_argument("--log-dir", default="logs", help="Log directory")
    
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run generation for a single keyword")
    run_parser.add_argument("keyword", help="Search keyword")
    run_parser.add_argument("--mode", default=Strategies.V1, choices=Strategies.ALL, help="Generation strategy")
    run_parser.add_argument("--output", help="Output JSON file")
    run_parser.add_argument("--mock", action="store_true", help="Mock API calls")
    run_parser.add_argument("--ignore-errors", action="store_true", help="Ignore API errors")
    run_parser.set_defaults(func=run_single_keyword)
    
    # Batch command
    batch_parser = subparsers.add_parser("batch", help="Run batch generation")
    batch_parser.add_argument("input_file", help="Input CSV/TXT file")
    batch_parser.add_argument("--output-file", default="batch_results.csv", help="Output CSV file")
    batch_parser.add_argument("--mode", default=Strategies.V1, choices=Strategies.ALL)
    batch_parser.add_argument("--mock", action="store_true", help="Mock API calls")
    batch_parser.set_defaults(func=run_batch)
    
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
