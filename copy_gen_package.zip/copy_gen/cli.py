
import argparse
import sys
import logging
import json
import csv
from pathlib import Path
from typing import List

from .config import load_config
from .utils.logging import setup_logging
from .core.workflow import CopyBlockWorkflow
from .clients.facet_api import get_facets
from .core.facet_mapper import FacetMapper

from .utils.mocks import apply_mocks

def run_single_keyword(args):
    """Run pipeline for a single keyword."""
    config = load_config(args.config)
    log_file, _ = setup_logging(args.log_dir)
    
    keyword = args.keyword
    mode = args.mode or "baseline"
    
    print(f"Processing keyword: {keyword} [Mode: {mode}]")
    
    if args.mock:
        apply_mocks()

    # Facets (Mock if requested, else API)
    facets = {} 
    if args.mock:
        facets = {"facet_list": [], "bread_crumb_list": []}
    else:
        # Real API call
        try:
            facets = get_facets(keyword, config)
        except Exception as e:
            logging.error(f"Failed to fetch facets: {e}")
            if not args.ignore_errors:
                raise

    # Breadcrumbs - simple extraction
    breadcrumbs = []
    for group in facets.get("bread_crumb_list", []):
        for val in group.get("values", []):
            breadcrumbs.append(val.get("label"))
    breadcrumb_str = " > ".join(breadcrumbs)

    # Load item types if needed for V1/V2
    item_types = []
    if mode in ["v1", "v2"]:
        it_path = config.get('data_paths', {}).get('item_types')
        if it_path and Path(it_path).exists():
             with open(it_path, 'r') as f:
                 item_types = json.load(f)

    # Run Workflow
    workflow = CopyBlockWorkflow(config, mode=mode)
    result = workflow.run(
        query=keyword,
        breadcrumb=breadcrumb_str,
        facet_results=facets,
        item_types=item_types
    )
    
    # Output
    print(json.dumps(result, indent=2))
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2)
            print(f"Result saved to {args.output}")

def run_batch(args):
    """Run pipeline for a batch of keywords."""
    config = load_config(args.config)
    setup_logging(args.log_dir)
    
    if args.mock:
        apply_mocks()
    
    # Read inputs
    keywords = []
    if args.input_file.endswith('.csv'):
        with open(args.input_file, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            # Basic header skip logic
            rows = list(reader)
            if rows and rows[0][0].lower() in ['keyword', 'query']:
                rows = rows[1:]
            keywords = [r[0] for r in rows if r]
    else:
         with open(args.input_file, 'r', encoding='utf-8') as f:
            keywords = [line.strip() for line in f if line.strip()]
            
    print(f"Starting batch processing for {len(keywords)} keywords [Mode: {args.mode}]...")
    
    results = []
    for i, kw in enumerate(keywords, 1):
        print(f"[{i}/{len(keywords)}] {kw}")
        try:
            workflow = CopyBlockWorkflow(config, mode=args.mode)
            facet_data = {}
            if not args.mock:
                 try:
                     facet_data = get_facets(kw, config)
                 except Exception:
                     logging.warning(f"Could not fetch facets for {kw}")
            
            res = workflow.run(kw, "", facet_data, [])
            
            # Extract fanouts list for CSV
            fanout_out = res.get("fanout_output", {})
            fanouts_data = fanout_out.get("fanouts", [])
            fanouts_str = json.dumps(fanouts_data)
            
            # Extract reasoning from various possible keys
            reasoning = (
                fanout_out.get("reasoning") or 
                fanout_out.get("brainstorming_process") or 
                fanout_out.get("validation_logic") or 
                ""
            )
            
            results.append({
                "keyword": kw, 
                "copy": res.get("final_copy"),
                "fanouts": fanouts_str,
                "reasoning": reasoning,
                "time": res.get("total_time")
            })
        except Exception as e:
            logging.error(f"Failed {kw}: {e}")
            results.append({"keyword": kw, "error": str(e)})

    # Save
    if args.output_file:
        keys = ["keyword", "copy", "fanouts", "reasoning", "time", "error"]
        with open(args.output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(results)
        print(f"Batch results saved to {args.output_file}")


def main():
    parser = argparse.ArgumentParser(prog="copy_gen", description="Copy Block Generator CLI")
    parser.add_argument("--config", default="conf.yml", help="Path to config file")
    parser.add_argument("--log-dir", default="logs", help="Log directory")
    
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run generation for a single keyword")
    run_parser.add_argument("keyword", help="Search keyword")
    run_parser.add_argument("--mode", default="baseline", choices=["baseline", "v1", "v2"], help="Generation strategy")
    run_parser.add_argument("--output", help="Output JSON file")
    run_parser.add_argument("--mock", action="store_true", help="Mock API calls")
    run_parser.add_argument("--ignore-errors", action="store_true", help="Ignore API errors")
    run_parser.set_defaults(func=run_single_keyword)
    
    # Batch command
    batch_parser = subparsers.add_parser("batch", help="Run batch generation")
    batch_parser.add_argument("input_file", help="Input CSV/TXT file")
    batch_parser.add_argument("--output-file", default="batch_results.csv", help="Output CSV file")
    batch_parser.add_argument("--mode", default="baseline", choices=["baseline", "v1", "v2"])
    batch_parser.add_argument("--mock", action="store_true", help="Mock API calls")
    batch_parser.set_defaults(func=run_batch)
    
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
