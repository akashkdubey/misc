"""
Facet mapper module for mapping facet value IDs to their display names.
"""

import csv
import logging
from pathlib import Path
from typing import Dict, List, Optional


class FacetMapper:
    """Maps facet value IDs to their display names using facet_definitions.csv"""
    
    def __init__(self, csv_path: Optional[str] = None, config: Optional[Dict] = None):
        """
        Initialize the FacetMapper.
        
        Args:
            csv_path (str, optional): Path to facet_definitions.csv. 
                                     If None, uses config or default path.
            config (dict, optional): Configuration dictionary from conf.yml
        """
        if csv_path is None:
            if config is not None:
                csv_path = config.get('data_paths', {}).get('facet_definitions', 'data/facet_definitions.csv')
            else:
                csv_path = Path(__file__).parent.parent.parent / "data" / "facet_definitions.csv"
        
        self.csv_path = Path(csv_path)
        self.facet_map = self._load_facet_definitions()
    
    def _load_facet_definitions(self) -> Dict[str, Dict[str, str]]:
        """
        Load facet definitions from CSV file.
        
        Returns:
            dict: Nested dictionary with structure:
                  {facet_type_id: {facet_value_id: facet_value}}
        """
        facet_map = {}
        
        logging.debug(f"Loading facet definitions from: {self.csv_path}")
        
        with open(self.csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                facet_type_id = row['facet_type_id']
                facet_value_id = row['facet_value_id']
                facet_value = row['facet_value']
                
                # Initialize facet_type if not exists
                if facet_type_id not in facet_map:
                    facet_map[facet_type_id] = {
                        'display_name': row['display_name'],
                        'values': {}
                    }
                
                # Map facet_value_id to facet_value
                facet_map[facet_type_id]['values'][facet_value_id] = facet_value
        
        logging.debug(f"Loaded {len(facet_map)} facet types from definitions")
        return facet_map
    
    def get_facet_display_name(self, facet_type_id: str) -> Optional[str]:
        """
        Get the display name for a facet type.
        
        Args:
            facet_type_id (str): Facet type ID (e.g., 'd_brand_all')
            
        Returns:
            str: Display name or None if not found
        """
        return self.facet_map.get(facet_type_id, {}).get('display_name')
    
    def get_facet_value_name(self, facet_type_id: str, facet_value_id: str) -> Optional[str]:
        """
        Get the display name for a specific facet value.
        
        Args:
            facet_type_id (str): Facet type ID (e.g., 'd_brand_all')
            facet_value_id (str): Facet value ID (e.g., '2l26w')
            
        Returns:
            str: Facet value display name or None if not found
        """
        return self.facet_map.get(facet_type_id, {}).get('values', {}).get(facet_value_id)
    
    def map_facet_values(self, facet_type_id: str, facet_value_ids: List[str]) -> List[Dict[str, str]]:
        """
        Map a list of facet value IDs to their display names.
        
        Args:
            facet_type_id (str): Facet type ID
            facet_value_ids (list): List of facet value IDs
            
        Returns:
            list: List of dicts with 'id' and 'name' keys
        """
        mapped_values = []
        for value_id in facet_value_ids:
            name = self.get_facet_value_name(facet_type_id, value_id)
            mapped_values.append({
                'id': value_id,
                'name': name if name else value_id  # Fallback to ID if name not found
            })
        return mapped_values
    
    def enrich_facets(self, facets: List[Dict]) -> List[Dict]:
        """
        Enrich facet data with display names.
        
        Args:
            facets (list): List of facet dictionaries with facet_type and popular_facet_values
            
        Returns:
            list: Enriched facet list with mapped names
        """
        enriched_facets = []
        
        logging.debug(f"Enriching {len(facets)} facets with display names")
        
        for facet in facets:
            facet_type = facet.get('facet_type')
            enriched_facet = facet.copy()
            
            # Add facet type display name
            display_name = self.get_facet_display_name(facet_type)
            if display_name:
                enriched_facet['facet_display_name'] = display_name
                logging.debug(f"Mapped facet type {facet_type} to '{display_name}'")
            
            # Map popular facet values if they exist
            if 'popular_facet_values' in facet:
                enriched_facet['popular_facet_values_mapped'] = self.map_facet_values(
                    facet_type, 
                    facet['popular_facet_values']
                )
                logging.debug(f"Mapped {len(facet['popular_facet_values'])} values for {facet_type}")
            
            enriched_facets.append(enriched_facet)
        
        return enriched_facets


def main():
    """Example usage of FacetMapper"""
    mapper = FacetMapper()
    
    # Example facet data
    example_facets = [
        {
            "facet_type": "d_brand_all",
            "rank_score": 0.10033105793150036,
            "popular_facet_values": ["2l26w", "st5r5", "xmf9o"]
        },
        {
            "facet_type": "d_product_color",
            "rank_score": 0.5000707638761527,
            "popular_facet_values": ["gup4zc5zk8t", "gup4zc5xkto"]
        }
    ]
    
    # Enrich facets
    enriched = mapper.enrich_facets(example_facets)
    
    import json
    print(json.dumps(enriched, indent=2))


if __name__ == "__main__":
    main()
