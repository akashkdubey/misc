"""
LangGraph flow for orchestrating fanout agent and copy generator agent.
"""

import json
import logging
import sys
from typing import Dict, Any

# TypedDict compatibility for Python 3.7
if sys.version_info >= (3, 8):
    from typing import TypedDict
else:
    try:
        from typing_extensions import TypedDict
    except ImportError:
        # Fallback for Python 3.7 without typing_extensions
        TypedDict = dict

from langgraph.graph import StateGraph, END
from ..clients.llm import AgentAPIClient


# ... (imports remain)

# Define the state schema for the graph
class GraphState(TypedDict):
    """State that flows through the graph."""
    query: str
    
    # New state for item types
    item_types: list
    item_types_json: str
    
    fanout_output: Dict[str, Any]
    fanout_output_json: str
    
    # For V2 intermediate state
    candidate_fanouts: list
    candidate_fanouts_json: str
    
    copy_output: Dict[str, Any]
    final_copy: str
    
    fanout_time: float
    copy_time: float


class CopyBlockWorkflow:
    """LangGraph workflow for generating copy blocks."""
    
    def __init__(self, config: Dict[str, Any], mode: str = "v1"):
        """
        Initialize the workflow with configuration.
        
        Args:
            config: Configuration dictionary loaded from conf.yml
            mode: Strategy mode ('v1', 'v2')
        """
        self.config = config
        self.mode = mode
        self.langgraph_config = config.get('langgraph', {})
        self.agent_client = AgentAPIClient(config)
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """
        Build the LangGraph state graph based on mode.
        """
        workflow = StateGraph(GraphState)
        
        if self.mode == "v2":
            # V2: Unconstrained Gen -> Filter -> Copy
            workflow.add_node("fanout_agent_v2_generate", self.fanout_agent_v2_generate_node)
            workflow.add_node("fanout_agent_v2_filter", self.fanout_agent_v2_filter_node)
            workflow.add_node("copy_generator_agent", self.copy_generator_node)
            
            workflow.set_entry_point("fanout_agent_v2_generate")
            workflow.add_edge("fanout_agent_v2_generate", "fanout_agent_v2_filter")
            workflow.add_edge("fanout_agent_v2_filter", "copy_generator_agent")
            workflow.add_edge("copy_generator_agent", END)
            
        else:
            # Default to V1: Constrained Fanout -> Copy
            workflow.add_node("fanout_agent_v1", self.fanout_agent_v1_node)
            workflow.add_node("copy_generator_agent", self.copy_generator_node)
            
            workflow.set_entry_point("fanout_agent_v1")
            workflow.add_edge("fanout_agent_v1", "copy_generator_agent")
            workflow.add_edge("copy_generator_agent", END)
        
        return workflow.compile()

    # --- Node Implementations ---

    def fanout_agent_v1_node(self, state: GraphState) -> GraphState:
        """V1 Step 1: Constrained Fanout (Query + Item Types)."""
        logging.info("Step 1 (V1): Generating constrained fanouts...")
        
        input_data = {
            "query": state['query'],
            "item_types": state['item_types_json']
        }
        
        fanout_output, time_taken = self.agent_client.call_agent_api('fanout_agent_v1', input_data)
        
        state['fanout_output'] = fanout_output
        state['fanout_output_json'] = json.dumps(fanout_output, indent=2)
        state['fanout_time'] = time_taken
        return state

    def fanout_agent_v2_generate_node(self, state: GraphState) -> GraphState:
        """V2 Step 1: Unconstrained Fanout Generation."""
        logging.info("Step 1 (V2): Generating unconstrained fanouts...")
        
        input_data = {
            "query": state['query']
        }
        
        result, time_taken = self.agent_client.call_agent_api('fanout_agent_v2_generate', input_data)
        
        fanouts = result.get('fanouts', [])
        state['candidate_fanouts'] = fanouts
        state['candidate_fanouts_json'] = json.dumps(fanouts, indent=2)
        state['fanout_time'] = time_taken 
        return state

    def fanout_agent_v2_filter_node(self, state: GraphState) -> GraphState:
        """V2 Step 2: Filter Fanouts using Item Types."""
        logging.info("Step 2 (V2): Filtering fanouts...")
        
        input_data = {
            "candidate_fanouts": state['candidate_fanouts_json'],
            "item_types": state['item_types_json']
        }
        
        filter_result, time_taken = self.agent_client.call_agent_api('fanout_agent_v2_filter', input_data)
        
        valid_fanouts = filter_result.get('valid_fanouts', [])
        must_cover = filter_result.get('must_cover', [])
        
        final_fanout_struct = {
            "canonical_query": state['query'], 
            "fanouts": valid_fanouts,
            "must_cover": must_cover
        }
        
        state['fanout_output'] = final_fanout_struct
        state['fanout_output_json'] = json.dumps(final_fanout_struct, indent=2)
        state['fanout_time'] += time_taken 
        return state

    def copy_generator_node(self, state: GraphState) -> GraphState:
        """Final Step: Generate marketing copy from fanouts."""
        logging.info("Final Step: Generating copy paragraph...")
        
        input_data = {
            "fanout_agent_output_json": state['fanout_output_json']
        }
        
        copy_output, time_taken = self.agent_client.call_agent_api('copy_generator_agent', input_data)
        final_copy = copy_output.get('copy', '')
        
        state['final_copy'] = final_copy
        state['copy_time'] = time_taken
        return state
    
    def run(self, query: str, item_types: list = None) -> Dict[str, Any]:
        """Run the workflow."""
        logging.info("="*60)
        logging.info(f"Running workflow [{self.mode.upper()}] for: {query}")
        logging.info("="*60)
        
        initial_state = GraphState(
            query=query,
            item_types=item_types or [],
            item_types_json=json.dumps(item_types or []) if item_types else "[]",
            fanout_output={},
            fanout_output_json="",
            candidate_fanouts=[],
            candidate_fanouts_json="[]",
            final_copy="",
            fanout_time=0.0,
            copy_time=0.0
        )
        
        final_state = self.graph.invoke(initial_state)
        
        total_time = final_state.get('fanout_time', 0.0) + final_state.get('copy_time', 0.0)
        
        return {
            "fanout_output": final_state.get('fanout_output', {}),
            "final_copy": final_state.get('final_copy', ''),
            "fanout_time": final_state.get('fanout_time', 0.0),
            "copy_time": final_state.get('copy_time', 0.0),
            "total_time": total_time,
            "mode": self.mode
        }
