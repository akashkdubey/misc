"""
Output formatters for Copy Block Generator.

Exports results to a single timestamp-named folder containing:
    - result.json (full output)
    - result.csv (flattened)
    - result.xlsx (styled spreadsheet)

For batch processing:
    - batch_report.json
    - batch_report.csv
    - batch_report.xlsx
"""

import csv
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime

# Try to import openpyxl for Excel support
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False


class OutputFormatter:
    """
    Format and save workflow outputs to various file formats.
    
    Output structure:
        {output_dir}/
        └── {timestamp}/           # e.g., 20260206_143639
            ├── result.json
            ├── result.csv
            └── result.xlsx
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Initialize the output formatter.
        
        Args:
            output_dir: Base directory for outputs
        """
        self.base_output_dir = Path(output_dir)
        self.base_output_dir.mkdir(parents=True, exist_ok=True)
        
        # Create timestamp folder for this run
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_dir = self.base_output_dir / self.timestamp
        self.run_dir.mkdir(parents=True, exist_ok=True)
    
    def save_all(self, result: Dict[str, Any], base_name: str = None) -> Dict[str, Path]:
        """
        Save result to all formats in the timestamp folder.
        
        Args:
            result: The workflow result dict
            base_name: Optional base name (default: 'result')
            
        Returns:
            Dict mapping format name to file path
        """
        base_name = base_name or "result"
        paths = {}
        
        # JSON - full output
        paths['json'] = self.save_json(result, base_name)
        
        # CSV - flattened
        paths['csv'] = self.save_csv(result, base_name)
        
        # Excel - validation friendly
        if EXCEL_AVAILABLE:
            paths['excel'] = self.save_excel(result, base_name)
        
        # Store run info
        paths['run_dir'] = self.run_dir
        
        return paths
    
    def save_json(self, result: Dict[str, Any], base_name: str) -> Path:
        """Save complete result as JSON."""
        path = self.run_dir / f"{base_name}.json"
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, default=str)
        return path
    
    def save_csv(self, result: Dict[str, Any], base_name: str) -> Path:
        """Save result as flattened CSV (single row)."""
        path = self.run_dir / f"{base_name}.csv"
        
        row = self._flatten_result_to_single_row(result)
        
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(row.keys()))
            writer.writeheader()
            writer.writerow(row)
        
        return path
    
    def save_excel(self, result: Dict[str, Any], base_name: str) -> Path:
        """Save result as Excel with flattened single-row structure."""
        if not EXCEL_AVAILABLE:
            raise ImportError("openpyxl required for Excel export. Install: pip install openpyxl")
        
        path = self.run_dir / f"{base_name}.xlsx"
        
        # Flatten
        row_data = self._flatten_result_to_single_row(result)
        
        # Write single row using common helper
        self._write_excel_file(path, [row_data], title="Results")
        return path

    def save_batch_report(self, results: List[Dict[str, Any]], base_name: str = "batch_report") -> Dict[str, Path]:
        """
        Save a batch of results into consolidated files in the timestamp folder.
        
        Args:
            results: List of workflow result dicts
            base_name: Base name for files (default: 'batch_report')
            
        Returns:
            Dict mapping format name to file path
        """
        paths = {}

        if not results:
            return paths

        # Save consolidated JSON
        json_path = self.run_dir / f"{base_name}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                "batch_summary": {
                    "total_keywords": len(results),
                    "timestamp": datetime.now().isoformat(),
                    "successful": sum(1 for r in results if r.get('validation', {}).get('overall_score', 0) > 0)
                },
                "results": results
            }, f, indent=2, default=str)
        paths['json'] = json_path

        flattened_rows = [self._flatten_result_to_single_row(r) for r in results]

        # Save CSV
        csv_path = self.run_dir / f"{base_name}.csv"
        headers = list(flattened_rows[0].keys())
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(flattened_rows)
        paths['csv'] = csv_path

        # Save Excel
        if EXCEL_AVAILABLE:
            xlsx_path = self.run_dir / f"{base_name}.xlsx"
            self._write_excel_file(xlsx_path, flattened_rows, title="Batch Results")
            paths['excel'] = xlsx_path
        
        paths['run_dir'] = self.run_dir
        return paths

    def _write_excel_file(self, path: Path, rows: List[Dict[str, Any]], title: str = "Results"):
        """Helper to write a list of flattened dictionaries to an Excel file with styling."""
        wb = Workbook()
        ws = wb.active
        ws.title = title
        
        if not rows:
            wb.save(path)
            return

        headers = list(rows[0].keys())
        styles = self._get_excel_styles()
        
        # Write Header
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = styles['header_font']
            cell.fill = styles['header_fill']
            cell.border = styles['border']
        
        # Write Data
        for r_idx, row_data in enumerate(rows, 2):
            for c_idx, header in enumerate(headers, 1):
                val = row_data.get(header, '')
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.alignment = styles['alignment']
                cell.border = styles['border']
                
                # Highlight issues
                if header == 'Overall Verdict' and val != 'PASS':
                    cell.fill = styles['warning_fill']
        
        # Adjust widths
        self._adjust_column_widths(ws, headers)
        
        wb.save(path)

    def _get_excel_styles(self) -> Dict[str, Any]:
        """Return common Excel styles."""
        return {
            'header_font': Font(bold=True, color="FFFFFF"),
            'header_fill': PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid"),
            'warning_fill': PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
            'border': Border(left=Side(style='thin'), right=Side(style='thin'), 
                           top=Side(style='thin'), bottom=Side(style='thin')),
            'alignment': Alignment(wrap_text=True, vertical="top")
        }

    def _adjust_column_widths(self, ws, headers):
        """Set nice column widths based on header name."""
        for col, header in enumerate(headers, 1):
            width = 30
            if 'Copy' in header: width = 80
            if 'Fanouts' in header: width = 50
            if 'Logic' in header: width = 50
            col_letter = chr(64+col) if col <= 26 else 'A' + chr(64+col-26)
            ws.column_dimensions[col_letter].width = width

    def _flatten_result_to_single_row(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Flatten entire result into a single dictionary (one row) for 4-stage pipeline."""
        
        # Extract main components
        categories = result.get('categories', [])
        fanout_output = result.get('fanout_output', {})
        fanouts = fanout_output.get('fanouts', []) if isinstance(fanout_output, dict) else []
        
        # Format Categories
        formatted_categories = []
        for cat in categories:
            if isinstance(cat, dict):
                formatted_categories.append(
                    f"{cat.get('item_type', 'N/A')} ({cat.get('role', 'core')}, score:{cat.get('score', 0)}) - {cat.get('rationale', '')}"
                )
        
        # Format Fanouts
        formatted_fanouts = []
        copy_seed_fanouts = []
        for f in fanouts:
            if isinstance(f, dict):
                fanout_str = f"{f.get('aisle_title', 'N/A')}: {f.get('query', 'N/A')} | Type: {f.get('item_type', 'N/A')} | Priority: {f.get('priority', 'N/A')}"
                formatted_fanouts.append(fanout_str)
                if f.get('use_in_copy'):
                    copy_seed_fanouts.append(f.get('aisle_title', 'N/A'))
        
        # Calculate totals
        total_retries = (
            result.get('query_normalizer_retries', 0) +
            result.get('category_identification_retries', 0) +
            result.get('fanout_expansion_retries', 0) +
            result.get('marketing_copy_retries', 0)
        )
        
        total_guardrail_time = (
            result.get('query_normalizer_guardrail_time', 0) +
            result.get('category_identification_guardrail_time', 0) +
            result.get('fanout_expansion_guardrail_time', 0) +
            result.get('marketing_copy_guardrail_time', 0)
        )
        
        copy_text = result.get('final_copy', '')
        word_count = len(copy_text.split()) if copy_text else 0
        
        return {
            # Input
            "Query": result.get('query', ''),
            "Timestamp": result.get('timestamp', ''),
            
            # Stage 1: Query Normalization
            "Normalized_Query": result.get('normalized_query', ''),
            "Stage1_Guardrail": result.get('query_normalizer_guardrail_verdict', 'NOT_RUN'),
            "Stage1_Retries": result.get('query_normalizer_retries', 0),
            "Stage1_Time": f"{result.get('query_normalizer_time', 0):.2f}",
            "Stage1_Guardrail_Time": f"{result.get('query_normalizer_guardrail_time', 0):.2f}",
            
            # Stage 2: Category Identification
            "Categories_Count": len(categories),
            "Categories": "\n".join(formatted_categories),
            "Stage2_Guardrail": result.get('category_identification_guardrail_verdict', 'NOT_RUN'),
            "Stage2_Retries": result.get('category_identification_retries', 0),
            "Stage2_Time": f"{result.get('category_identification_time', 0):.2f}",
            "Stage2_Guardrail_Time": f"{result.get('category_identification_guardrail_time', 0):.2f}",
            
            # Stage 3: Fanout Expansion
            "Fanouts_Count": len(fanouts),
            "Fanouts": "\n".join(formatted_fanouts),
            "Copy_Seed_Fanouts": ", ".join(copy_seed_fanouts),
            "Stage3_Guardrail": result.get('fanout_expansion_guardrail_verdict', 'NOT_RUN'),
            "Stage3_Retries": result.get('fanout_expansion_retries', 0),
            "Stage3_Time": f"{result.get('fanout_expansion_time', 0):.2f}",
            "Stage3_Guardrail_Time": f"{result.get('fanout_expansion_guardrail_time', 0):.2f}",
            
            # Stage 4: Marketing Copy
            "Copy_Word_Count": word_count,
            "Marketing_Copy": copy_text,
            "Stage4_Guardrail": result.get('marketing_copy_guardrail_verdict', 'NOT_RUN'),
            "Stage4_Retries": result.get('marketing_copy_retries', 0),
            "Stage4_Time": f"{result.get('marketing_copy_time', 0):.2f}",
            "Stage4_Guardrail_Time": f"{result.get('marketing_copy_guardrail_time', 0):.2f}",
            
            # Summary
            "Total_Retries": total_retries,
            "Total_Time": f"{result.get('total_time', 0):.2f}",
            "Total_Guardrail_Time": f"{total_guardrail_time:.2f}",
            "Log_File": result.get('log_file', '')
        }