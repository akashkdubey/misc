"""
Mock System - Simulates LLM responses for testing without API calls.

Provides mock responses for all 8 agents in the 4-stage pipeline:
    - Stage 1: Query Normalizer + Guardrail
    - Stage 2: Category Identification + Guardrail
    - Stage 3: Fanout Expansion + Guardrail
    - Stage 4: Marketing Copy + Guardrail

Usage:
    from copy_gen.utils.mocks import apply_mocks
    apply_mocks()  # Must be called before running the workflow
"""

from unittest.mock import MagicMock
from typing import Dict, Any, Tuple

# Track call counts per agent for simulating retry scenarios
_call_counts: Dict[str, int] = {}


def apply_mocks() -> None:
    """
    Apply mocks to AgentAPIClient to avoid live API calls.
    
    Call this function before running the workflow in test/mock mode.
    """
    from ..clients.llm import AgentAPIClient
    
    global _call_counts
    _call_counts = {}
    
    AgentAPIClient.call_agent_api = MagicMock(side_effect=mock_agent_response)


def mock_agent_response(agent_name: str, input_data: Dict[str, Any]) -> Tuple[Dict[str, Any], float]:
    """
    Generate mock response based on agent name.
    
    Args:
        agent_name: Name of the agent being called
        input_data: Input data (used for context in response)
        
    Returns:
        Tuple of (response_dict, simulated_time_seconds)
    """
    global _call_counts
    _call_counts[agent_name] = _call_counts.get(agent_name, 0) + 1
    call_num = _call_counts[agent_name]
    
    # Stage 1: Query Normalization
    if agent_name == 'query_normalizer_agent':
        return _mock_query_normalizer(input_data, call_num)
    
    if agent_name == 'query_normalizer_guardrail_agent':
        return _mock_query_normalizer_guardrail(call_num)
    
    # Stage 2: Category Identification
    if agent_name == 'category_identification_agent':
        return _mock_category_identification(input_data, call_num)
    
    if agent_name == 'category_identification_guardrail_agent':
        return _mock_category_identification_guardrail(call_num)
    
    # Stage 3: Fanout Expansion
    if agent_name == 'fanout_expansion_agent':
        return _mock_fanout_expansion(input_data, call_num)
    
    if agent_name == 'fanout_expansion_guardrail_agent':
        return _mock_fanout_expansion_guardrail(call_num)
    
    # Stage 4: Marketing Copy
    if agent_name == 'marketing_copy_agent':
        return _mock_marketing_copy(input_data, call_num)
    
    if agent_name == 'marketing_copy_guardrail_agent':
        return _mock_marketing_copy_guardrail(call_num)
    
    # Unknown agent
    return {"error": f"Unknown agent: {agent_name}"}, 0.1


# =============================================================================
# Stage 1: Query Normalization Mocks
# =============================================================================

def _mock_query_normalizer(input_data: Dict[str, Any], call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock query normalizer response."""
    query = input_data.get('query', 'living room ideas')
    
    # Simulate normalization: remove "ideas", "inspiration", etc.
    normalized = query.lower()
    for word in ['ideas', 'inspiration', 'inspo', 'decorating']:
        normalized = normalized.replace(word, '').strip()
    
    # Clean up and add product focus
    normalized = ' '.join(normalized.split())  # Remove extra spaces
    if not normalized:
        normalized = "home products"
    
    return {"normalized_query": normalized}, 0.5


def _mock_query_normalizer_guardrail(call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock query normalizer guardrail response."""
    return {
        "stage": "normalization_qa",
        "format_check": {"passed": True, "issues": []},
        "shoppable_check": {"passed": True, "issues": []},
        "intent_check": {"passed": True, "issues": []},
        "domain_injection_check": {"passed": True, "issues": []},
        "overall_verdict": "PASS",
        "improvement_suggestions": []
    }, 0.3


# =============================================================================
# Stage 2: Category Identification Mocks
# =============================================================================

def _mock_category_identification(input_data: Dict[str, Any], call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock category identification response."""
    return {
        "selected_categories": [
            {"item_type": "Sofas", "label": "Sofas", "role": "core", "score": 95, "rationale": "Primary seating for living room"},
            {"item_type": "Coffee Tables", "label": "Coffee Tables", "role": "core", "score": 90, "rationale": "Essential living room furniture"},
            {"item_type": "Accent Chairs", "label": "Accent Chairs", "role": "core", "score": 85, "rationale": "Additional seating options"},
            {"item_type": "Floor Lamps", "label": "Floor Lamps", "role": "supporting", "score": 75, "rationale": "Lighting to complement furniture"},
            {"item_type": "Area Rugs", "label": "Area Rugs", "role": "supporting", "score": 70, "rationale": "Defines living room space"},
            {"item_type": "Throw Pillows", "label": "Throw Pillows", "role": "supporting", "score": 65, "rationale": "Decorative accessories"}
        ]
    }, 0.8


def _mock_category_identification_guardrail(call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock category identification guardrail response."""
    return {
        "stage": "category_mapping_qa",
        "format_check": {"passed": True, "issues": []},
        "catalog_check": {"passed": True, "issues": []},
        "count_and_fields_check": {"passed": True, "issues": []},
        "relevance_check": {"passed": True, "issues": []},
        "redundancy_check": {"passed": True, "issues": []},
        "overall_verdict": "PASS",
        "improvement_suggestions": []
    }, 0.4


# =============================================================================
# Stage 3: Fanout Expansion Mocks
# =============================================================================

def _mock_fanout_expansion(input_data: Dict[str, Any], call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock fanout expansion response."""
    return {
        "fanouts": [
            {"aisle_title": "Comfortable Sofas", "query": "comfortable sofas for small spaces", "item_type": "Sofas", "priority": "high", "use_in_copy": True},
            {"aisle_title": "Modern Coffee Tables", "query": "modern coffee tables with storage", "item_type": "Coffee Tables", "priority": "high", "use_in_copy": True},
            {"aisle_title": "Cozy Accent Chairs", "query": "cozy accent chairs for living room", "item_type": "Accent Chairs", "priority": "high", "use_in_copy": True},
            {"aisle_title": "Sectional Sofas", "query": "sectional sofas for apartments", "item_type": "Sofas", "priority": "medium", "use_in_copy": True},
            {"aisle_title": "Reading Lamps", "query": "floor lamps for reading", "item_type": "Floor Lamps", "priority": "medium", "use_in_copy": False},
            {"aisle_title": "Velvet Accent Chairs", "query": "velvet accent chairs", "item_type": "Accent Chairs", "priority": "medium", "use_in_copy": False},
            {"aisle_title": "Round Coffee Tables", "query": "round coffee tables wood", "item_type": "Coffee Tables", "priority": "low", "use_in_copy": False},
            {"aisle_title": "Living Room Rugs", "query": "area rugs for living room", "item_type": "Area Rugs", "priority": "low", "use_in_copy": False}
        ]
    }, 1.2


def _mock_fanout_expansion_guardrail(call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock fanout expansion guardrail response."""
    return {
        "stage": "fanout_qa",
        "format_check": {"passed": True, "issues": []},
        "count_check": {"passed": True, "issues": []},
        "type_mapping_check": {"passed": True, "issues": []},
        "browsing_intent_check": {"passed": True, "issues": []},
        "quality_uniqueness_check": {"passed": True, "issues": []},
        "copy_seed_check": {"passed": True, "issues": []},
        "overall_verdict": "PASS",
        "improvement_suggestions": []
    }, 0.5


# =============================================================================
# Stage 4: Marketing Copy Mocks
# =============================================================================

def _mock_marketing_copy(input_data: Dict[str, Any], call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock marketing copy response."""
    copy_text = (
        "Transform your living space with comfortable sofas for small spaces and modern coffee tables "
        "that blend style with function. Whether you are furnishing a cozy apartment or refreshing a "
        "spacious family room, our collection offers something for every taste and budget. Explore "
        "plush sectional sofas perfect for movie nights, or discover sleek glass coffee tables that "
        "add contemporary elegance. For those who love mid-century aesthetics, browse our velvet accent "
        "chairs with clean lines and warm wood tones. From farmhouse-inspired wooden coffee tables to "
        "luxurious leather sofas, our living room furniture covers every style imaginable. Complete your "
        "space with floor lamps and decorative accents that tie the room together beautifully."
    )
    return {"copy": copy_text}, 1.5


def _mock_marketing_copy_guardrail(call_num: int) -> Tuple[Dict[str, Any], float]:
    """Mock marketing copy guardrail response."""
    return {
        "stage": "copy_qa",
        "format_check": {"passed": True, "issues": []},
        "compliance_check": {"passed": True, "issues": [], "word_count": 115},
        "banned_wording_check": {"passed": True, "issues": []},
        "tone_check": {"passed": True, "issues": []},
        "stitching_check": {"passed": True, "issues": []},
        "relevance_check": {"passed": True, "issues": []},
        "overall_verdict": "PASS",
        "improvement_suggestions": []
    }, 0.4
