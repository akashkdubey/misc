"""
Copy Block Workflow - Orchestrates 4-stage agent pipeline using LangGraph.
Stage 1: Query Normalization
Stage 2: Category Identification
Stage 3: Fanout Expansion  
Stage 4: Marketing Copy Generation
"""

import logging
from typing import Dict, Any

from langgraph.graph import StateGraph, END

from .state import GraphState, create_initial_state
from ..clients.llm import AgentAPIClient
from ..agents.query_normalizer import QueryNormalizerAgent, QueryNormalizerGuardrailAgent
from ..agents.category_identification import CategoryIdentificationAgent, CategoryIdentificationGuardrailAgent
from ..agents.fanout_expansion import FanoutExpansionAgent, FanoutExpansionGuardrailAgent
from ..agents.marketing_copy import MarketingCopyAgent, MarketingCopyGuardrailAgent

logger = logging.getLogger(__name__)


class CopyBlockWorkflow:
    """LangGraph workflow for 4-stage copy generation with guardrails at each stage."""
    
    def __init__(self, config: Dict[str, Any], mode: str = "v4"):
        self.config = config
        self.mode = mode
        self.agent_client = AgentAPIClient(config)
        
        # Guardrail settings
        guardrail_config = config.get('guardrails', {})
        self.query_normalizer_guardrail_enabled = guardrail_config.get('query_normalizer_guardrail_enabled', True)
        self.category_identification_guardrail_enabled = guardrail_config.get('category_identification_guardrail_enabled', True)
        self.fanout_expansion_guardrail_enabled = guardrail_config.get('fanout_expansion_guardrail_enabled', True)
        self.marketing_copy_guardrail_enabled = guardrail_config.get('marketing_copy_guardrail_enabled', True)
        
        self.query_normalizer_max_retries = guardrail_config.get('query_normalizer_max_retries', 2)
        self.category_identification_max_retries = guardrail_config.get('category_identification_max_retries', 2)
        self.fanout_expansion_max_retries = guardrail_config.get('fanout_expansion_max_retries', 2)
        self.marketing_copy_max_retries = guardrail_config.get('marketing_copy_max_retries', 2)
        
        self.retry_on_needs_review = guardrail_config.get('retry_on_needs_review', True)
        
        # Initialize agents
        self._init_agents()
        
        # Build graph
        self.graph = self._build_graph()
    
    def _init_agents(self):
        """Initialize all agent instances."""
        self.query_normalizer = QueryNormalizerAgent(self.agent_client, self.config)
        self.query_normalizer_guardrail = QueryNormalizerGuardrailAgent(self.agent_client, self.config)
        
        self.category_identification = CategoryIdentificationAgent(self.agent_client, self.config)
        self.category_identification_guardrail = CategoryIdentificationGuardrailAgent(self.agent_client, self.config)
        
        self.fanout_expansion = FanoutExpansionAgent(self.agent_client, self.config)
        self.fanout_expansion_guardrail = FanoutExpansionGuardrailAgent(self.agent_client, self.config)
        
        self.marketing_copy = MarketingCopyAgent(self.agent_client, self.config)
        self.marketing_copy_guardrail = MarketingCopyGuardrailAgent(self.agent_client, self.config)
    
    def _should_retry_query_normalizer(self, state: GraphState) -> str:
        """Decide whether to retry query normalization."""
        verdict = state.get('query_normalizer_guardrail_verdict', 'PASS')
        retry_count = state.get('query_normalizer_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.query_normalizer_max_retries:
            logger.info(f"Query Normalizer Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.query_normalizer_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.query_normalizer_max_retries:
            logger.warning(f"Query Normalizer Guardrail: {verdict} - max retries reached")
        
        return 'proceed'
    
    def _should_retry_category_identification(self, state: GraphState) -> str:
        """Decide whether to retry category identification."""
        verdict = state.get('category_identification_guardrail_verdict', 'PASS')
        retry_count = state.get('category_identification_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.category_identification_max_retries:
            logger.info(f"Category Identification Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.category_identification_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.category_identification_max_retries:
            logger.warning(f"Category Identification Guardrail: {verdict} - max retries reached")
        
        return 'proceed'
    
    def _should_retry_fanout_expansion(self, state: GraphState) -> str:
        """Decide whether to retry fanout expansion."""
        verdict = state.get('fanout_expansion_guardrail_verdict', 'PASS')
        retry_count = state.get('fanout_expansion_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.fanout_expansion_max_retries:
            logger.info(f"Fanout Expansion Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.fanout_expansion_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.fanout_expansion_max_retries:
            logger.warning(f"Fanout Expansion Guardrail: {verdict} - max retries reached")
        
        return 'proceed'
    
    def _should_retry_marketing_copy(self, state: GraphState) -> str:
        """Decide whether to retry marketing copy."""
        verdict = state.get('marketing_copy_guardrail_verdict', 'PASS')
        retry_count = state.get('marketing_copy_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.marketing_copy_max_retries:
            logger.info(f"Marketing Copy Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.marketing_copy_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.marketing_copy_max_retries:
            logger.warning(f"Marketing Copy Guardrail: {verdict} - max retries reached")
        
        return 'end'
    
    def _build_graph(self) -> StateGraph:
        """Build the 4-stage LangGraph pipeline."""
        workflow = StateGraph(GraphState)
        
        # Stage 1: Query Normalization
        workflow.add_node("query_normalizer_agent", self.query_normalizer)
        workflow.set_entry_point("query_normalizer_agent")
        
        if self.query_normalizer_guardrail_enabled:
            workflow.add_node("query_normalizer_guardrail_agent", self.query_normalizer_guardrail)
            workflow.add_edge("query_normalizer_agent", "query_normalizer_guardrail_agent")
            workflow.add_conditional_edges(
                "query_normalizer_guardrail_agent",
                self._should_retry_query_normalizer,
                {'retry': 'query_normalizer_agent', 'proceed': 'category_identification_agent'}
            )
        else:
            workflow.add_edge("query_normalizer_agent", "category_identification_agent")
        
        # Stage 2: Category Identification
        workflow.add_node("category_identification_agent", self.category_identification)
        
        if self.category_identification_guardrail_enabled:
            workflow.add_node("category_identification_guardrail_agent", self.category_identification_guardrail)
            workflow.add_edge("category_identification_agent", "category_identification_guardrail_agent")
            workflow.add_conditional_edges(
                "category_identification_guardrail_agent",
                self._should_retry_category_identification,
                {'retry': 'category_identification_agent', 'proceed': 'fanout_expansion_agent'}
            )
        else:
            workflow.add_edge("category_identification_agent", "fanout_expansion_agent")
        
        # Stage 3: Fanout Expansion
        workflow.add_node("fanout_expansion_agent", self.fanout_expansion)
        
        if self.fanout_expansion_guardrail_enabled:
            workflow.add_node("fanout_expansion_guardrail_agent", self.fanout_expansion_guardrail)
            workflow.add_edge("fanout_expansion_agent", "fanout_expansion_guardrail_agent")
            workflow.add_conditional_edges(
                "fanout_expansion_guardrail_agent",
                self._should_retry_fanout_expansion,
                {'retry': 'fanout_expansion_agent', 'proceed': 'marketing_copy_agent'}
            )
        else:
            workflow.add_edge("fanout_expansion_agent", "marketing_copy_agent")
        
        # Stage 4: Marketing Copy
        workflow.add_node("marketing_copy_agent", self.marketing_copy)
        
        if self.marketing_copy_guardrail_enabled:
            workflow.add_node("marketing_copy_guardrail_agent", self.marketing_copy_guardrail)
            workflow.add_edge("marketing_copy_agent", "marketing_copy_guardrail_agent")
            workflow.add_conditional_edges(
                "marketing_copy_guardrail_agent",
                self._should_retry_marketing_copy,
                {'retry': 'marketing_copy_agent', 'end': END}
            )
        else:
            workflow.add_edge("marketing_copy_agent", END)
        
        return workflow.compile()

    def run(self, query: str, item_types: list = None) -> Dict[str, Any]:
        """Run the workflow."""
        logger.info("=" * 60)
        logger.info(f"Running 4-stage workflow for: {query}")
        logger.info(f"Query Normalizer guardrail: {'ENABLED' if self.query_normalizer_guardrail_enabled else 'DISABLED'}")
        logger.info(f"Category Identification guardrail: {'ENABLED' if self.category_identification_guardrail_enabled else 'DISABLED'}")
        logger.info(f"Fanout Expansion guardrail: {'ENABLED' if self.fanout_expansion_guardrail_enabled else 'DISABLED'}")
        logger.info(f"Marketing Copy guardrail: {'ENABLED' if self.marketing_copy_guardrail_enabled else 'DISABLED'}")
        logger.info("=" * 60)
        
        initial_state = create_initial_state(query, item_types)
        final_state = self.graph.invoke(initial_state)
        
        return self._build_result(final_state)
    
    def _build_result(self, final_state: GraphState) -> Dict[str, Any]:
        """Build the result dictionary from final state."""
        total_time = (
            final_state.get('query_normalizer_time', 0) + 
            final_state.get('category_identification_time', 0) +
            final_state.get('fanout_expansion_time', 0) + 
            final_state.get('marketing_copy_time', 0) +
            final_state.get('query_normalizer_guardrail_time', 0) +
            final_state.get('category_identification_guardrail_time', 0) +
            final_state.get('fanout_expansion_guardrail_time', 0) +
            final_state.get('marketing_copy_guardrail_time', 0)
        )
        
        return {
            "query": final_state.get('query', ''),
            "normalized_query": final_state.get('normalized_query', ''),
            "categories": final_state.get('categories', []),
            "fanout_output": final_state.get('fanout_output', {}),
            "final_copy": final_state.get('final_copy', ''),
            "query_normalizer_time": final_state.get('query_normalizer_time', 0),
            "category_identification_time": final_state.get('category_identification_time', 0),
            "fanout_expansion_time": final_state.get('fanout_expansion_time', 0),
            "marketing_copy_time": final_state.get('marketing_copy_time', 0),
            "query_normalizer_guardrail_time": final_state.get('query_normalizer_guardrail_time', 0),
            "category_identification_guardrail_time": final_state.get('category_identification_guardrail_time', 0),
            "fanout_expansion_guardrail_time": final_state.get('fanout_expansion_guardrail_time', 0),
            "marketing_copy_guardrail_time": final_state.get('marketing_copy_guardrail_time', 0),
            "total_time": total_time,
            "query_normalizer_guardrail_verdict": final_state.get('query_normalizer_guardrail_verdict', 'NOT_RUN'),
            "query_normalizer_retries": max(0, final_state.get('query_normalizer_retry_count', 0) - 1),
            "category_identification_guardrail_verdict": final_state.get('category_identification_guardrail_verdict', 'NOT_RUN'),
            "category_identification_retries": max(0, final_state.get('category_identification_retry_count', 0) - 1),
            "fanout_expansion_guardrail_verdict": final_state.get('fanout_expansion_guardrail_verdict', 'NOT_RUN'),
            "fanout_expansion_retries": max(0, final_state.get('fanout_expansion_retry_count', 0) - 1),
            "marketing_copy_guardrail_verdict": final_state.get('marketing_copy_guardrail_verdict', 'NOT_RUN'),
            "marketing_copy_retries": max(0, final_state.get('marketing_copy_retry_count', 0) - 1),
        }
