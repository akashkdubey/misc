"""
GraphState definition for the Copy Block workflow - 4 stages.
"""

import sys
from typing import Dict, Any, List

# TypedDict compatibility
if sys.version_info >= (3, 8):
    from typing import TypedDict
else:
    try:
        from typing_extensions import TypedDict
    except ImportError:
        TypedDict = dict


class GraphState(TypedDict):
    """State that flows through the LangGraph workflow."""
    
    # Input
    query: str
    item_types: list
    item_types_json: str
    
    # Stage 1: Query Normalizer
    normalized_query: str
    normalized_query_output: Dict[str, Any]
    query_normalizer_time: float
    query_normalizer_guardrail_output: Dict[str, Any]
    query_normalizer_guardrail_verdict: str
    query_normalizer_guardrail_feedback: str
    query_normalizer_retry_count: int
    query_normalizer_guardrail_time: float
    
    # Stage 2: Category Identification
    categories: list
    categories_json: str
    category_identification_output: Dict[str, Any]
    category_identification_time: float
    category_identification_guardrail_output: Dict[str, Any]
    category_identification_guardrail_verdict: str
    category_identification_guardrail_feedback: str
    category_identification_retry_count: int
    category_identification_guardrail_time: float
    
    # Stage 3: Fanout Expansion
    fanout_output: Dict[str, Any]
    fanout_output_json: str
    fanout_expansion_time: float
    fanout_expansion_guardrail_output: Dict[str, Any]
    fanout_expansion_guardrail_verdict: str
    fanout_expansion_guardrail_feedback: str
    fanout_expansion_retry_count: int
    fanout_expansion_guardrail_time: float
    
    # Stage 4: Marketing Copy
    copy_output: Dict[str, Any]
    final_copy: str
    marketing_copy_output: Dict[str, Any]
    marketing_copy_time: float
    marketing_copy_guardrail_output: Dict[str, Any]
    marketing_copy_guardrail_verdict: str
    marketing_copy_guardrail_feedback: str
    marketing_copy_retry_count: int
    marketing_copy_guardrail_time: float


def create_initial_state(query: str, item_types: list = None) -> GraphState:
    """Create the initial state for a workflow run."""
    import json
    
    return GraphState(
        query=query,
        item_types=item_types or [],
        item_types_json=json.dumps(item_types or []),
        
        # Stage 1: Query Normalizer
        normalized_query="",
        normalized_query_output={},
        query_normalizer_time=0.0,
        query_normalizer_guardrail_output={},
        query_normalizer_guardrail_verdict="",
        query_normalizer_guardrail_feedback="",
        query_normalizer_retry_count=0,
        query_normalizer_guardrail_time=0.0,
        
        # Stage 2: Category Identification
        categories=[],
        categories_json="[]",
        category_identification_output={},
        category_identification_time=0.0,
        category_identification_guardrail_output={},
        category_identification_guardrail_verdict="",
        category_identification_guardrail_feedback="",
        category_identification_retry_count=0,
        category_identification_guardrail_time=0.0,
        
        # Stage 3: Fanout Expansion
        fanout_output={},
        fanout_output_json="",
        fanout_expansion_time=0.0,
        fanout_expansion_guardrail_output={},
        fanout_expansion_guardrail_verdict="",
        fanout_expansion_guardrail_feedback="",
        fanout_expansion_retry_count=0,
        fanout_expansion_guardrail_time=0.0,
        
        # Stage 4: Marketing Copy
        copy_output={},
        final_copy="",
        marketing_copy_output={},
        marketing_copy_time=0.0,
        marketing_copy_guardrail_output={},
        marketing_copy_guardrail_verdict="",
        marketing_copy_guardrail_feedback="",
        marketing_copy_retry_count=0,
        marketing_copy_guardrail_time=0.0,
    )
