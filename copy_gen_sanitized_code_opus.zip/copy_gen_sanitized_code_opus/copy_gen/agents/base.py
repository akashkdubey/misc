"""
Base Agent - Abstract base class for all Copy Block agents.

All agents in the 4-stage pipeline implement this interface:
    - agent_name: Used to look up prompt templates and config
    - build_input(): Transform graph state into LLM input
    - process_output(): Transform LLM output into state updates
    - __call__(): LangGraph node function
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Any

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Abstract base class for all agents in the Copy Block pipeline.
    
    Provides a consistent interface for:
        - Building input data from graph state
        - Calling the LLM via AgentAPIClient
        - Processing output and updating state
    
    Subclasses must implement:
        - agent_name: Property returning the agent's name (used for config/prompts)
        - build_input(): Transform state into LLM input dict
        - process_output(): Transform LLM result into state updates
        - __call__(): LangGraph node function
    """
    
    def __init__(self, agent_client, config: Dict[str, Any]):
        """
        Initialize the agent.
        
        Args:
            agent_client: AgentAPIClient instance for LLM calls
            config: Application configuration dict
        """
        self.agent_client = agent_client
        self.config = config
        self.guardrails_config = config.get('guardrails', {})
    
    @property
    @abstractmethod
    def agent_name(self) -> str:
        """
        The agent name used to look up prompt templates and config.
        
        Must match keys in:
            - conf.yml > prompts > agents
            - conf.yml > agents (for LLM settings)
        """
        pass
    
    @abstractmethod
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build the input dict for the LLM call from graph state.
        
        Args:
            state: Current LangGraph state dict
            
        Returns:
            Dict of input parameters for the prompt template
        """
        pass
    
    @abstractmethod
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process LLM output and return state updates.
        
        Args:
            result: Parsed JSON response from LLM
            state: Current LangGraph state dict
            
        Returns:
            Dict of state keys to update (NOT the full state).
            Use '_' prefix for internal keys that won't be added to state.
        """
        pass
    
    def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the agent: build input -> call LLM -> process output.
        
        Args:
            state: Current LangGraph state dict
            
        Returns:
            Dict of state updates (includes _time_taken)
        """
        input_data = self.build_input(state)
        result, time_taken = self.agent_client.call_agent_api(self.agent_name, input_data)
        
        updates = self.process_output(result, state)
        updates['_time_taken'] = time_taken
        
        return updates
    
    def apply_updates(self, state: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply updates to state immutably (returns new state dict).
        
        Filters out internal keys starting with '_'.
        
        Args:
            state: Current state dict
            updates: Updates to apply
            
        Returns:
            New state dict with updates applied
        """
        new_state = dict(state)
        for key, value in updates.items():
            if not key.startswith('_'):
                new_state[key] = value
        return new_state
    
    def log_info(self, message: str) -> None:
        """Log an info message with consistent formatting."""
        logger.info(message)
    
    def log_warning(self, message: str) -> None:
        """Log a warning message with consistent formatting."""
        logger.warning(f"  - {message}")
    
    def log_error(self, message: str) -> None:
        """Log an error message with consistent formatting."""
        logger.error(f"  ❌ {message}")
