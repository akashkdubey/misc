"""
Copy Block Agents - 4-Stage Agent System

Stage 1: Query Normalization
Stage 2: Category Identification
Stage 3: Fanout Expansion
Stage 4: Marketing Copy

Each stage has a main agent and a guardrail agent for validation.
"""

from .base import BaseAgent
from .query_normalizer import QueryNormalizerAgent, QueryNormalizerGuardrailAgent
from .category_identification import CategoryIdentificationAgent, CategoryIdentificationGuardrailAgent
from .fanout_expansion import FanoutExpansionAgent, FanoutExpansionGuardrailAgent
from .marketing_copy import MarketingCopyAgent, MarketingCopyGuardrailAgent

__all__ = [
    # Base
    'BaseAgent',
    # Stage 1
    'QueryNormalizerAgent',
    'QueryNormalizerGuardrailAgent',
    # Stage 2
    'CategoryIdentificationAgent',
    'CategoryIdentificationGuardrailAgent',
    # Stage 3
    'FanoutExpansionAgent',
    'FanoutExpansionGuardrailAgent',
    # Stage 4
    'MarketingCopyAgent',
    'MarketingCopyGuardrailAgent',
]
