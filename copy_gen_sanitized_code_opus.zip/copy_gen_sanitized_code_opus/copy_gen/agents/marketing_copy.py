"""
Marketing Copy Agent - Stage 4 of the Copy Block pipeline.

Generates a 100-120 word marketing paragraph for the product landing page.
"""

import json
import logging
from typing import Dict, Any, List

from .base import BaseAgent

logger = logging.getLogger(__name__)


class MarketingCopyAgent(BaseAgent):
    """
    Generates compelling marketing copy paragraph.
    
    Input from state:
        - query: Original user query
        - normalized_query: Normalized query from Stage 1
        - fanout_output_json: Fanout queries from Stage 3
    
    Updates state:
        - final_copy: The marketing paragraph
        - marketing_copy_output: Full output dict
        - marketing_copy_time: Execution time
    """
    
    @property
    def agent_name(self) -> str:
        return 'marketing_copy_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for the LLM call from graph state."""
        input_data = {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'selected_categories': state.get('categories_json', '[]'),
            'fanouts': state.get('fanout_output_json', '{}')
        }
        
        # On retry, include feedback for improvement
        feedback = state.get('marketing_copy_guardrail_feedback', '')
        previous_output = state.get('final_copy', '')
        
        if feedback and previous_output:
            input_data['improvement_feedback'] = feedback
            input_data['previous_output'] = json.dumps({'copy': previous_output})
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process LLM output and return state updates."""
        retry_count = state.get('marketing_copy_retry_count', 0)
        
        # Parse copy from response
        copy_text = result.get('copy', '')
        word_count = len(copy_text.split()) if copy_text else 0
        
        step_name = f"marketing_copy{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        self.log_info(f"Generated copy: {word_count} words")
        
        return {
            'final_copy': copy_text,
            'marketing_copy_output': result,
            '_validation_result': {
                'step': step_name,
                'word_count': word_count,
                'copy_preview': copy_text[:100] + '...' if len(copy_text) > 100 else copy_text
            }
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('marketing_copy_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Marketing Copy: RETRY {retry_count}")
        else:
            self.log_info("Step 4: Generating marketing copy...")
        
        updates = self.run(state)
        
        # Build new state (immutable pattern)
        new_state = self.apply_updates(state, updates)
        new_state['marketing_copy_time'] = (
            state.get('marketing_copy_time', 0) + updates['_time_taken']
        )
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state


class MarketingCopyGuardrailAgent(BaseAgent):
    """
    Validates marketing copy output.
    
    Checks:
        - Format: Valid JSON with 'copy' key
        - Compliance: Single paragraph, 100-120 words, ASCII punctuation
        - Banned wording: No "ideas", "inspiration", "guide", etc.
        - Tone: Retail marketing, not fiction/poetic
        - Anti-stitching: Doesn't read like a checklist
        - Relevance: Covers key fanout themes
    
    Updates state:
        - marketing_copy_guardrail_output: Validation details
        - marketing_copy_guardrail_verdict: PASS/FAIL/NEEDS_REVIEW
        - marketing_copy_guardrail_feedback: Suggestions for improvement
        - marketing_copy_retry_count: Incremented
    """
    
    @property
    def agent_name(self) -> str:
        return 'marketing_copy_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for guardrail validation."""
        return {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'selected_categories': state.get('categories_json', '[]'),
            'fanouts': state.get('fanout_output_json', '{}'),
            'copy_output': json.dumps({'copy': state.get('final_copy', '')})
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process guardrail validation result."""
        verdict = result.get('overall_verdict', 'FAIL')
        suggestions = result.get('improvement_suggestions', [])
        
        # Build feedback from check results
        feedback_parts = []
        for check_name in ['format_check', 'compliance_check', 'banned_wording_check',
                           'tone_check', 'stitching_check', 'relevance_check']:
            check_result = result.get(check_name, {})
            if not check_result.get('passed', True):
                issues = check_result.get('issues', [])
                if issues:
                    feedback_parts.append(f"{check_name.upper()}: {'; '.join(issues)}")
        
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('marketing_copy_retry_count', 0)
        self.log_info(f"Marketing Copy Guardrail: Validating (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Marketing Copy Guardrail verdict: {updates['_verdict']}")
        for suggestion in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {suggestion}")
        
        # Build new state
        new_state = dict(state)
        new_state['marketing_copy_guardrail_output'] = updates['_output']
        new_state['marketing_copy_guardrail_verdict'] = updates['_verdict']
        new_state['marketing_copy_guardrail_feedback'] = updates['_feedback']
        new_state['marketing_copy_guardrail_time'] = (
            state.get('marketing_copy_guardrail_time', 0) + updates['_time_taken']
        )
        new_state['marketing_copy_retry_count'] = retry_count + 1
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            'step': f"marketing_copy_guardrail_attempt_{retry_count + 1}",
            'is_valid': updates['_verdict'] == 'PASS',
            'verdict': updates['_verdict'],
            'warnings': updates['_suggestions'],
            'attempt': retry_count + 1
        })
        new_state['validation_results'] = validation_results
        
        return new_state
