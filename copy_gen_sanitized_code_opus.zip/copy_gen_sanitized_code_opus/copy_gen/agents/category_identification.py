"""
Category Identification Agent - Stage 2 of the Copy Block pipeline.

Identifies 4-8 relevant product categories from the catalog based on the normalized query.
"""

import json
import logging
from typing import Dict, Any, List

from .base import BaseAgent

logger = logging.getLogger(__name__)


class CategoryIdentificationAgent(BaseAgent):
    """
    Identifies relevant product categories from inventory.
    
    Input from state:
        - query: Original user query
        - normalized_query: Normalized query from Stage 1
        - item_types: Available product categories
    
    Updates state:
        - categories: List of selected categories
        - categories_json: JSON string of categories
        - category_identification_time: Execution time
    """
    
    @property
    def agent_name(self) -> str:
        return 'category_identification_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for the LLM call from graph state."""
        input_data = {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'catalog_item_types': state.get('item_types_json', '[]')
        }
        
        # On retry, include feedback for improvement
        feedback = state.get('category_identification_guardrail_feedback', '')
        previous_output = state.get('categories_json', '')
        
        if feedback and previous_output:
            input_data['improvement_feedback'] = feedback
            input_data['previous_output'] = previous_output
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process LLM output and return state updates."""
        retry_count = state.get('category_identification_retry_count', 0)
        
        # Parse categories from response
        selected_categories = result.get('selected_categories', [])
        categories_json = json.dumps(selected_categories)
        
        category_count = len(selected_categories)
        step_name = f"category_identification{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        self.log_info(f"Identified {category_count} categories")
        
        return {
            'categories': selected_categories,
            'categories_json': categories_json,
            'category_identification_output': result,
            '_validation_result': {
                'step': step_name,
                'category_count': category_count,
                'categories': [c.get('item_type', '') for c in selected_categories if isinstance(c, dict)]
            }
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('category_identification_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Category Identification: RETRY {retry_count}")
        else:
            self.log_info("Step 2: Identifying product categories...")
        
        updates = self.run(state)
        
        # Build new state (immutable pattern)
        new_state = self.apply_updates(state, updates)
        new_state['category_identification_time'] = (
            state.get('category_identification_time', 0) + updates['_time_taken']
        )
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state


class CategoryIdentificationGuardrailAgent(BaseAgent):
    """
    Validates category identification output.
    
    Checks:
        - Format: Valid JSON with selected_categories array
        - Catalog compliance: All item_types exist in catalog
        - Count: 4-8 categories selected
        - Relevance: Categories match the query intent
    
    Updates state:
        - category_identification_guardrail_output: Validation details
        - category_identification_guardrail_verdict: PASS/FAIL/NEEDS_REVIEW
        - category_identification_guardrail_feedback: Suggestions for improvement
        - category_identification_retry_count: Incremented
    """
    
    @property
    def agent_name(self) -> str:
        return 'category_identification_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for guardrail validation."""
        return {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'catalog_item_types': state.get('item_types_json', '[]'),
            'category_output': state.get('categories_json', '[]')
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process guardrail validation result."""
        verdict = result.get('overall_verdict', 'FAIL')
        suggestions = result.get('improvement_suggestions', [])
        
        # Build feedback from check results
        feedback_parts = []
        for check_name in ['format_check', 'catalog_check', 'count_and_fields_check', 
                           'relevance_check', 'redundancy_check']:
            check_result = result.get(check_name, {})
            if not check_result.get('passed', True):
                issues = check_result.get('issues', [])
                if issues:
                    feedback_parts.append(f"{check_name.upper()}: {'; '.join(issues)}")
        
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('category_identification_retry_count', 0)
        self.log_info(f"Category Identification Guardrail: Validating (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Category Identification Guardrail verdict: {updates['_verdict']}")
        for suggestion in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {suggestion}")
        
        # Build new state
        new_state = dict(state)
        new_state['category_identification_guardrail_output'] = updates['_output']
        new_state['category_identification_guardrail_verdict'] = updates['_verdict']
        new_state['category_identification_guardrail_feedback'] = updates['_feedback']
        new_state['category_identification_guardrail_time'] = (
            state.get('category_identification_guardrail_time', 0) + updates['_time_taken']
        )
        new_state['category_identification_retry_count'] = retry_count + 1
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            'step': f"category_identification_guardrail_attempt_{retry_count + 1}",
            'is_valid': updates['_verdict'] == 'PASS',
            'verdict': updates['_verdict'],
            'warnings': updates['_suggestions'],
            'attempt': retry_count + 1
        })
        new_state['validation_results'] = validation_results
        
        return new_state
