"""
Fanout Expansion Agent - Stage 3 of the Copy Block pipeline.

Generates 6-12 shopper-friendly search phrases for each selected category.
"""

import json
import logging
from typing import Dict, Any, List

from .base import BaseAgent

logger = logging.getLogger(__name__)


class FanoutExpansionAgent(BaseAgent):
    """
    Generates fanout queries for each category.
    
    Input from state:
        - query: Original user query
        - normalized_query: Normalized query from Stage 1
        - categories: List of selected categories from Stage 2
    
    Updates state:
        - fanout_output: Fanouts grouped with metadata
        - fanout_output_json: JSON string
        - fanout_expansion_time: Execution time
    """
    
    @property
    def agent_name(self) -> str:
        return 'fanout_expansion_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for the LLM call from graph state."""
        input_data = {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'selected_categories': state.get('categories_json', '[]')
        }
        
        # On retry, include feedback for improvement
        feedback = state.get('fanout_expansion_guardrail_feedback', '')
        previous_output = state.get('fanout_output_json', '')
        
        if feedback and previous_output:
            input_data['improvement_feedback'] = feedback
            input_data['previous_output'] = previous_output
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process LLM output and return state updates."""
        retry_count = state.get('fanout_expansion_retry_count', 0)
        
        # Parse fanouts from response
        fanouts = result.get('fanouts', [])
        fanout_output_json = json.dumps(result)
        total_fanouts = len(fanouts)
        
        step_name = f"fanout_expansion{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        self.log_info(f"Generated {total_fanouts} fanouts")
        
        return {
            'fanout_output': result,
            'fanout_output_json': fanout_output_json,
            '_validation_result': {
                'step': step_name,
                'fanout_count': total_fanouts,
                'use_in_copy_count': sum(1 for f in fanouts if isinstance(f, dict) and f.get('use_in_copy'))
            }
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('fanout_expansion_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Fanout Expansion: RETRY {retry_count}")
        else:
            self.log_info("Step 3: Generating fanout queries...")
        
        updates = self.run(state)
        
        # Build new state (immutable pattern)
        new_state = self.apply_updates(state, updates)
        new_state['fanout_expansion_time'] = (
            state.get('fanout_expansion_time', 0) + updates['_time_taken']
        )
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state


class FanoutExpansionGuardrailAgent(BaseAgent):
    """
    Validates fanout expansion output.
    
    Checks:
        - Format: Valid JSON with fanouts array
        - Count: 6-12 fanouts generated
        - Type mapping: All item_types match selected categories
        - Browsing intent: No informational phrasing
        - Quality: No duplicates, readable aisle titles
        - Copy seeds: 3-5 fanouts marked use_in_copy=true
    
    Updates state:
        - fanout_expansion_guardrail_output: Validation details
        - fanout_expansion_guardrail_verdict: PASS/FAIL/NEEDS_REVIEW
        - fanout_expansion_guardrail_feedback: Suggestions for improvement
        - fanout_expansion_retry_count: Incremented
    """
    
    @property
    def agent_name(self) -> str:
        return 'fanout_expansion_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build input for guardrail validation."""
        return {
            'canonical_query': state.get('query', ''),
            'normalized_query': state.get('normalized_query', ''),
            'selected_categories': state.get('categories_json', '[]'),
            'fanout_output': state.get('fanout_output_json', '{}')
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Process guardrail validation result."""
        verdict = result.get('overall_verdict', 'FAIL')
        suggestions = result.get('improvement_suggestions', [])
        
        # Build feedback from check results
        feedback_parts = []
        for check_name in ['format_check', 'count_check', 'type_mapping_check', 
                           'browsing_intent_check', 'quality_uniqueness_check', 'copy_seed_check']:
            check_result = result.get(check_name, {})
            if not check_result.get('passed', True):
                issues = check_result.get('issues', [])
                if issues:
                    feedback_parts.append(f"{check_name.upper()}: {'; '.join(issues)}")
        
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('fanout_expansion_retry_count', 0)
        self.log_info(f"Fanout Expansion Guardrail: Validating (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Fanout Expansion Guardrail verdict: {updates['_verdict']}")
        for suggestion in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {suggestion}")
        
        # Build new state
        new_state = dict(state)
        new_state['fanout_expansion_guardrail_output'] = updates['_output']
        new_state['fanout_expansion_guardrail_verdict'] = updates['_verdict']
        new_state['fanout_expansion_guardrail_feedback'] = updates['_feedback']
        new_state['fanout_expansion_guardrail_time'] = (
            state.get('fanout_expansion_guardrail_time', 0) + updates['_time_taken']
        )
        new_state['fanout_expansion_retry_count'] = retry_count + 1
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            'step': f"fanout_expansion_guardrail_attempt_{retry_count + 1}",
            'is_valid': updates['_verdict'] == 'PASS',
            'verdict': updates['_verdict'],
            'warnings': updates['_suggestions'],
            'attempt': retry_count + 1
        })
        new_state['validation_results'] = validation_results
        
        return new_state
