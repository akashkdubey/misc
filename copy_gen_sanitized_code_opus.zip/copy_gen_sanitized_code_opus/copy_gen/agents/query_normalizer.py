"""
Query Normalizer Agent - Normalizes vague queries into clear shopper intent.
"""

import json
import logging
from typing import Dict, Any

from .base import BaseAgent

logger = logging.getLogger(__name__)


class QueryNormalizerAgent(BaseAgent):
    """Normalize vague or inspirational queries into clear product-seeking queries."""
    
    @property
    def agent_name(self) -> str:
        return 'query_normalizer_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        input_data = {
            "canonical_query": state['query']
        }
        
        # On retry, include feedback
        feedback = state.get('query_normalizer_guardrail_feedback', '')
        previous_output = state.get('normalized_query', '')
        
        if feedback and previous_output:
            input_data["improvement_feedback"] = feedback
            input_data["previous_output"] = json.dumps({"normalized_query": previous_output})
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        normalized_query = result.get('normalized_query', '')
        retry_count = state.get('query_normalizer_retry_count', 0)
        
        step_name = f"query_normalizer{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        self.log_info(f"Normalized query: '{normalized_query}'")
        
        return {
            'normalized_query': normalized_query,
            'normalized_query_json': json.dumps(result, indent=2),
            '_validation_result': {"step": step_name, "normalized_query": normalized_query}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('query_normalizer_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Query Normalizer: RETRY {retry_count}")
        else:
            self.log_info("Step 1: Normalizing query...")
        
        updates = self.run(state)
        
        new_state = self.apply_updates(state, updates)
        new_state['query_normalizer_time'] = state.get('query_normalizer_time', 0) + updates['_time_taken']
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state


class QueryNormalizerGuardrailAgent(BaseAgent):
    """Validate query normalization output using QA checklist."""
    
    @property
    def agent_name(self) -> str:
        return 'query_normalizer_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "canonical_query": state['query'],
            "normalizer_output": json.dumps({"normalized_query": state['normalized_query']})
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        verdict = result.get('overall_verdict', 'PASS')
        suggestions = result.get('improvement_suggestions', [])
        
        # Build feedback
        feedback_parts = []
        for check in ['intent_alignment', 'clarity_specificity', 'no_misinterpretation', 'shoppable_phrasing']:
            check_result = result.get(check, {})
            if not check_result.get('passed', True):
                fb = check_result.get('feedback', '')
                if fb:
                    feedback_parts.append(f"{check.upper()}: {fb}")
        
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('query_normalizer_retry_count', 0)
        self.log_info(f"Query Normalizer Guardrail: Validating (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Query Normalizer Guardrail verdict: {updates['_verdict']}")
        for s in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {s}")
        
        new_state = dict(state)
        new_state['query_normalizer_guardrail_output'] = updates['_output']
        new_state['query_normalizer_guardrail_verdict'] = updates['_verdict']
        new_state['query_normalizer_guardrail_feedback'] = updates['_feedback']
        new_state['query_normalizer_guardrail_time'] = state.get('query_normalizer_guardrail_time', 0) + updates['_time_taken']
        new_state['query_normalizer_retry_count'] = retry_count + 1
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            "step": f"query_normalizer_guardrail_attempt_{retry_count + 1}",
            "is_valid": updates['_verdict'] == 'PASS',
            "verdict": updates['_verdict'],
            "warnings": updates['_suggestions'],
            "attempt": retry_count + 1
        })
        new_state['validation_results'] = validation_results
        
        return new_state
