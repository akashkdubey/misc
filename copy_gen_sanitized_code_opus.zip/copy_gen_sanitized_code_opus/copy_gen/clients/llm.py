"""
LLM Client - Sends requests to the LLM chat/completions endpoint.

Handles:
    - Building message payloads (prompt as system, input as user message)
    - Agent-specific LLM settings (model, temperature, etc.)
    - Multi-turn conversation for retry with feedback
    - Response parsing and JSON extraction
    - Retry logic for transient failures
"""

import os
import json
import logging
import time
import requests
from typing import Dict, Any, Tuple, Optional

from ..utils.guardrails import sanitize_json_response

logger = logging.getLogger(__name__)


class AgentAPIClient:
    """
    Client that sends message-style requests to an LLM endpoint.
    
    Message structure:
        - System: Base system prompt (from config)
        - User: Prompt instructions (from file) + Input data (as JSON)
    
    call_agent_api(agent_name, input_data) returns (parsed_result_dict, elapsed_seconds).
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the LLM client.
        
        Args:
            config: Application configuration dict containing 'llm' and 'agents' sections
        """
        self.config = config
        llm_config = config.get('llm', {})

        # Required: base URL
        self.base_url = llm_config.get('base_url')
        if not self.base_url:
            raise ValueError("llm.base_url not configured in conf.yml")

        # Endpoints
        self.chat_url = f"{self.base_url.rstrip('/')}/chat/completions"
        
        # General LLM settings
        self.application_name = llm_config.get('application_name', 'copy_block')
        self.api_key = llm_config.get('api_key', '')
        self.verify_ssl = llm_config.get('verify_ssl', True)
        self.timeout = llm_config.get('timeout', 60)
        self.max_retries = llm_config.get('max_retries', 3)
        self.reasoning_effort = llm_config.get('reasoning_effort', 'low')
        
        # Default agent settings
        self.default_agent_config = config.get('agents', {}).get('default', {})
        
        # Workflow settings
        self.system_prompt = config.get('workflow', {}).get(
            'system_prompt', 
            "You are a helpful assistant for a mainstream e-commerce retailer."
        )

    def _get_agent_config(self, agent_name: str) -> Dict[str, Any]:
        """
        Get LLM settings for a specific agent.
        
        Falls back to default settings if agent-specific config not found.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Dict with model, temperature, max_tokens, reasoning_effort
        """
        agents_config = self.config.get('agents', {})
        agent_config = agents_config.get(agent_name, {})
        
        # Merge with defaults
        return {
            'model': agent_config.get('model', self.default_agent_config.get('model', 'gpt-4.1-mini')),
            'temperature': agent_config.get('temperature', self.default_agent_config.get('temperature', 1.0)),
            'max_tokens': agent_config.get('max_tokens', self.default_agent_config.get('max_tokens', 1024)),
            'reasoning_effort': agent_config.get('reasoning_effort', self.reasoning_effort),
        }

    def _load_prompt(self, agent_name: str) -> Optional[str]:
        """
        Load the prompt template for an agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Prompt template string or None if not found
        """
        prompts_cfg = self.config.get('prompts', {})
        prompts_dir = prompts_cfg.get('dir') or self.config.get('data_paths', {}).get('prompts_dir', 'prompts')
        agent_prompt_file = prompts_cfg.get('agents', {}).get(agent_name)

        if not agent_prompt_file:
            return None
            
        prompt_path = f"{prompts_dir.rstrip('/')}/{agent_prompt_file}"
        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            logger.warning(f"Prompt file not found at {prompt_path}")
            return None

    def _build_messages(self, agent_name: str, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build a messages payload for the LLM.
        
        Structure:
            - System: Base system prompt
            - User: Prompt instructions + Input data as JSON
        
        Args:
            agent_name: Name of the agent (used to look up prompt template)
            input_data: Input data to pass to the agent
            
        Returns:
            Request payload dict with model, messages, and settings
        """
        # Load prompt template (instructions only, no placeholders)
        prompt_text = self._load_prompt(agent_name)
        
        # Build messages with clean separation
        messages = [{"role": "system", "content": self.system_prompt}]
        
        if prompt_text:
            # First user message: the instructions
            messages.append({"role": "user", "content": prompt_text})
            
            # Check for retry/feedback scenario
            improvement_feedback = input_data.get('improvement_feedback', '')
            previous_output = input_data.get('previous_output', '')
            
            # Filter out meta keys for clean input
            clean_input = {k: v for k, v in input_data.items() 
                          if k not in ('improvement_feedback', 'previous_output')}
            
            if improvement_feedback and previous_output:
                # Multi-turn: simulate assistant response, then feedback
                messages.append({"role": "assistant", "content": "I understand the task. Please provide the input."})
                messages.append({"role": "user", "content": json.dumps(clean_input, indent=2)})
                messages.append({"role": "assistant", "content": previous_output})
                messages.append({"role": "user", "content": f"Please revise your output. Issues found:\n{improvement_feedback}"})
            else:
                # Normal flow: assistant acknowledges, then input
                messages.append({"role": "assistant", "content": "I understand the task. Please provide the input."})
                messages.append({"role": "user", "content": json.dumps(clean_input, indent=2)})
        else:
            # Fallback: just send input as user message
            messages.append({"role": "user", "content": json.dumps(input_data, indent=2)})

        # Get agent-specific LLM settings
        agent_config = self._get_agent_config(agent_name)

        return {
            "model": agent_config['model'],
            "messages": messages,
            "temperature": agent_config['temperature'],
            "max_new_tokens": agent_config['max_tokens'],
            "reasoning_effort": agent_config['reasoning_effort'],
            "stream": False,
        }

    def _extract_content(self, resp_json: Dict[str, Any]) -> str:
        """
        Extract content from various LLM response formats.
        
        Handles:
            - result.output.content
            - data.output.content
            - choices[0].message.content (OpenAI style)
        
        Args:
            resp_json: Raw JSON response from LLM
            
        Returns:
            Extracted content string
        """
        if isinstance(resp_json, dict):
            # Format 1: result.output.content
            if 'output' in resp_json and isinstance(resp_json['output'], dict):
                if 'content' in resp_json['output']:
                    return resp_json['output']['content']

            # Format 2: data.output.content
            if 'data' in resp_json and isinstance(resp_json['data'], dict):
                out = resp_json['data'].get('output')
                if isinstance(out, dict) and 'content' in out:
                    return out['content']

            # Format 3: OpenAI/Chat-style choices[0].message.content
            if 'choices' in resp_json and resp_json['choices']:
                choice = resp_json['choices'][0]
                if isinstance(choice, dict):
                    msg = choice.get('message') or choice.get('delta')
                    if isinstance(msg, dict) and 'content' in msg:
                        return msg['content']
                    if 'text' in choice:
                        return choice.get('text')

        # Fallback: return as JSON string
        try:
            return json.dumps(resp_json)
        except Exception:
            return str(resp_json)

    def _parse_response(self, content_str: str, agent_name: str) -> Dict[str, Any]:
        """
        Parse LLM response content into a dict.
        
        Args:
            content_str: Raw content string from LLM
            agent_name: Agent name for logging
            
        Returns:
            Parsed dict result
        """
        if isinstance(content_str, dict):
            return content_str
            
        # Try guardrails sanitizer first (handles markdown code blocks)
        parsed = sanitize_json_response(content_str)
        if parsed is not None:
            return parsed
        
        # Fallback: direct JSON parse
        try:
            return json.loads(content_str)
        except json.JSONDecodeError:
            logger.warning(f"LLM response for {agent_name} is not valid JSON")
            return {"text": content_str}

    def call_agent_api(self, agent_name: str, input_data: Dict[str, Any]) -> Tuple[Dict[str, Any], float]:
        """
        Send request to the LLM and return parsed JSON + elapsed time.
        
        Args:
            agent_name: Name of the agent
            input_data: Input data for the agent
            
        Returns:
            Tuple of (parsed_result_dict, elapsed_seconds)
            
        Raises:
            Exception: If all retries fail
        """
        payload = self._build_messages(agent_name, input_data)
        headers = self._build_headers()

        overall_start = time.time()
        last_error = None

        for attempt in range(1, self.max_retries + 1):
            try:
                logger.info(f"Calling LLM for {agent_name} (attempt {attempt}/{self.max_retries})")
                
                resp = requests.post(
                    self.chat_url, 
                    headers=headers, 
                    json=payload, 
                    timeout=self.timeout, 
                    verify=self.verify_ssl
                )
                
                if resp.status_code == 200:
                    resp_json = resp.json()
                    content_str = self._extract_content(resp_json)
                    logger.debug(f"LLM raw content for {agent_name}: {str(content_str)[:2000]}")
                    
                    parsed_result = self._parse_response(content_str, agent_name)
                    logger.info(f"Parsed LLM result for {agent_name}: {type(parsed_result).__name__}")

                    elapsed = time.time() - overall_start
                    return parsed_result, elapsed

                # Retry on transient errors
                if resp.status_code in {429, 500, 502, 503}:
                    wait = 2 ** attempt
                    logger.warning(f"LLM transient status {resp.status_code}, retrying after {wait}s")
                    time.sleep(wait)
                    continue

                # Non-retriable error
                logger.error(f"LLM call failed ({resp.status_code}): {resp.text[:1000]}")
                return {}, time.time() - overall_start

            except requests.RequestException as e:
                logger.error(f"LLM request exception: {e}")
                last_error = e
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    break

        if last_error:
            raise last_error
        raise ValueError("LLM call failed after retries")

    def _build_headers(self) -> Dict[str, str]:
        """
        Build HTTP headers for LLM request.
        
        Returns:
            Headers dict with auth and content type
        """
        headers = {
            "Content-Type": "application/json",
            "X-TGT-APPLICATION": self.application_name,
        }
        
        # Prefer API key header if provided
        if self.api_key:
            headers['x-api-key'] = self.api_key
        else:
            # Fall back to bearer token from env or config
            bearer = os.getenv('BEARER_TOKEN') or self.config.get('api', {}).get('agents', {}).get('bearer_token')
            if bearer:
                headers['Authorization'] = f"Bearer {bearer}"
        
        return headers