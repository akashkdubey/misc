# Architecture Documentation

This document explains the technical architecture of the Copy Block Generator, including how agents communicate, how data flows through the pipeline, and how to extend the system.

---

## Table of Contents

1. [System Overview](#system-overview)
2. [The 4-Stage Pipeline](#the-4-stage-pipeline)
3. [How Agents Work](#how-agents-work)
4. [Message Passing & State Management](#message-passing--state-management)
5. [LLM Communication Pattern](#llm-communication-pattern)
6. [Guardrail & Retry Mechanism](#guardrail--retry-mechanism)
7. [Adding New Agents](#adding-new-agents)
8. [Configuration System](#configuration-system)

---

## System Overview

The Copy Block Generator is built on **LangGraph**, a library for building stateful, graph-based AI workflows. The architecture follows these principles:

- **Agent-based**: Each stage is an independent agent with clear inputs/outputs
- **State-driven**: All agents communicate through a shared state dictionary
- **Self-correcting**: Guardrail agents validate output and trigger retries
- **Configurable**: All behavior is tunable via `conf.yml`

```
                    ┌─────────────────────────────────────────┐
                    │            CopyBlockWorkflow            │
                    │          (LangGraph StateGraph)         │
                    └─────────────────────────────────────────┘
                                        │
            ┌───────────────────────────┴───────────────────────────┐
            │                     SHARED STATE                      │
            │  {query, normalized_query, categories, fanouts, ...}  │
            └───────────────────────────────────────────────────────┘
                    │           │           │           │
                    ▼           ▼           ▼           ▼
               ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
               │ Stage 1 │ │ Stage 2 │ │ Stage 3 │ │ Stage 4 │
               │ Agent + │ │ Agent + │ │ Agent + │ │ Agent + │
               │Guardrail│ │Guardrail│ │Guardrail│ │Guardrail│
               └─────────┘ └─────────┘ └─────────┘ └─────────┘
```

---

## The 4-Stage Pipeline

### Stage 1: Query Normalization

**Purpose**: Convert vague/inspirational queries into shoppable search phrases.

| Input | Output |
|-------|--------|
| `"living room ideas"` | `"living room furniture"` |
| `"birthday gift ideas for her"` | `"birthday gifts for her"` |

**Files**:
- Agent: `copy_gen/agents/query_normalizer.py`
- Prompt: `prompts/query_normalizer.txt`
- Guardrail Prompt: `prompts/query_normalizer_guardrail.txt`

---

### Stage 2: Category Identification

**Purpose**: Select 4-8 product categories from the catalog that match the query intent.

| Input | Output |
|-------|--------|
| Normalized query + Category catalog | Selected categories with roles & rationale |

**Output structure**:
```json
{
  "selected_categories": [
    {"item_type": "Sofas", "role": "core", "score": 95, "rationale": "Primary furniture"},
    {"item_type": "Coffee Tables", "role": "core", "score": 90, "rationale": "Essential"},
    {"item_type": "Floor Lamps", "role": "supporting", "score": 70, "rationale": "Lighting"}
  ]
}
```

**Files**:
- Agent: `copy_gen/agents/category_identification.py`
- Prompt: `prompts/category_identification.txt`

---

### Stage 3: Fanout Expansion

**Purpose**: Generate 6-12 shopper-friendly search queries (fanouts) that will become product aisles.

| Input | Output |
|-------|--------|
| Query + Categories | Fanout queries with priorities |

**Output structure**:
```json
{
  "fanouts": [
    {
      "aisle_title": "Comfortable Sofas",
      "query": "comfortable sofas for small spaces",
      "item_type": "Sofas",
      "priority": "high",
      "use_in_copy": true
    }
  ]
}
```

**Files**:
- Agent: `copy_gen/agents/fanout_expansion.py`
- Prompt: `prompts/fanout_expansion.txt`

---

### Stage 4: Marketing Copy

**Purpose**: Write a 100-120 word marketing paragraph for the product grid.

| Input | Output |
|-------|--------|
| Query + Categories + Fanouts | Single paragraph marketing copy |

**Rules enforced**:
- No banned words (ideas, inspiration, guide, tips)
- No meta-references (this page, SEO, keywords)
- No poetic language (imagine, picture this)
- Anti-stitching (doesn't read like a checklist)

**Files**:
- Agent: `copy_gen/agents/marketing_copy.py`
- Prompt: `prompts/marketing_copy.txt`

---

## How Agents Work

All agents extend the `BaseAgent` abstract class:

```python
class BaseAgent(ABC):
    """Abstract base class for all pipeline agents."""
    
    def __init__(self, agent_client: AgentAPIClient, config: Dict[str, Any]):
        self.agent_client = agent_client
        self.config = config
    
    @property
    @abstractmethod
    def agent_name(self) -> str:
        """Unique identifier used for config lookup and logging."""
        pass
    
    @abstractmethod
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract data from state and package as input for LLM."""
        pass
    
    @abstractmethod
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """Parse LLM response and return state updates."""
        pass
    
    def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute: build_input → call LLM → process_output."""
        input_data = self.build_input(state)
        result, time_taken = self.agent_client.call_agent_api(self.agent_name, input_data)
        updates = self.process_output(result, state)
        updates['_time_taken'] = time_taken
        return updates
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function. Runs agent and updates state."""
        pass  # Implemented by each agent
```

---

## Message Passing & State Management

### The State Dictionary

All agents communicate through a shared state dictionary (`GraphState`):

```python
class GraphState(TypedDict):
    # Input
    query: str
    item_types: List[str]
    
    # Stage 1 outputs
    normalized_query: str
    query_normalizer_guardrail_verdict: str
    query_normalizer_retries: int
    
    # Stage 2 outputs
    categories: List[Dict]
    categories_json: str
    category_identification_guardrail_verdict: str
    
    # Stage 3 outputs
    fanout_output: Dict
    fanout_output_json: str
    fanout_expansion_guardrail_verdict: str
    
    # Stage 4 outputs
    final_copy: str
    marketing_copy_guardrail_verdict: str
    
    # Timing
    total_time: float
```

### How Data Flows

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              STATE DICTIONARY                               │
│                                                                             │
│  {                                                                          │
│    query: "living room ideas",           ◄── Input (from user)             │
│    normalized_query: "living room",      ◄── Stage 1 writes                │
│    categories: [...],                    ◄── Stage 2 writes                │
│    fanout_output: {fanouts: [...]},      ◄── Stage 3 writes                │
│    final_copy: "..."                     ◄── Stage 4 writes                │
│  }                                                                          │
└─────────────────────────────────────────────────────────────────────────────┘
                │                   │                   │
                ▼                   ▼                   ▼
        ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
        │    Stage 1    │   │    Stage 2    │   │    Stage 3    │
        │               │   │               │   │               │
        │ build_input() │   │ build_input() │   │ build_input() │
        │   reads:      │   │   reads:      │   │   reads:      │
        │   - query     │   │   - query     │   │   - query     │
        │               │   │   - norm_query│   │   - norm_query│
        │               │   │   - item_types│   │   - categories│
        │               │   │               │   │               │
        │ Writes:       │   │ Writes:       │   │ Writes:       │
        │ - norm_query  │   │ - categories  │   │ - fanouts     │
        └───────────────┘   └───────────────┘   └───────────────┘
```

### Example: Stage 2 Reading Stage 1 Output

```python
# In CategoryIdentificationAgent.build_input()
def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'canonical_query': state.get('query', ''),           # Original input
        'normalized_query': state.get('normalized_query', ''), # From Stage 1
        'catalog_item_types': state.get('item_types_json', '[]')
    }
```

---

## LLM Communication Pattern

### Clean Input Separation

We use a **clean separation pattern** where:
- **System message**: Base system prompt
- **User message 1**: Task instructions (the prompt template)
- **Assistant message**: "I understand the task. Please provide the input."
- **User message 2**: Input data as JSON

```
┌──────────────────────────────────────────────────────────────┐
│ Message 1 (System):                                          │
│ "You are a helpful assistant for a mainstream e-commerce     │
│  retailer."                                                  │
├──────────────────────────────────────────────────────────────┤
│ Message 2 (User):                                            │
│ "You are a Category Mapping Agent. Your job is to map the    │
│  query intent to our catalog item types.                     │
│                                                              │
│  TASK: Select 4–8 item types from the provided catalog..."   │
├──────────────────────────────────────────────────────────────┤
│ Message 3 (Assistant):                                       │
│ "I understand the task. Please provide the input."           │
├──────────────────────────────────────────────────────────────┤
│ Message 4 (User):                                            │
│ {                                                            │
│   "canonical_query": "living room ideas",                    │
│   "normalized_query": "living room",                         │
│   "catalog_item_types": ["Sofas", "Coffee Tables", ...]      │
│ }                                                            │
└──────────────────────────────────────────────────────────────┘
```

### Benefits of This Pattern

1. **Clear separation** of instructions vs data
2. **Easier prompt maintenance** - no placeholder injection
3. **Safer** - reduces prompt injection risks
4. **Better for retries** - can add conversation history

---

## Guardrail & Retry Mechanism

### How Guardrails Work

Each main agent has a corresponding guardrail agent that validates its output:

```
┌─────────────────┐     ┌─────────────────┐
│   Main Agent    │────►│ Guardrail Agent │
│  (generates)    │     │  (validates)    │
└─────────────────┘     └─────────────────┘
                               │
                    ┌──────────┴──────────┐
                    │                     │
                    ▼                     ▼
               ┌─────────┐          ┌─────────┐
               │  PASS   │          │  FAIL   │
               │ (next   │          │ (retry  │
               │  stage) │          │  agent) │
               └─────────┘          └─────────┘
```

### Conditional Edges in LangGraph

```python
# In workflow.py
def _should_retry_category(self, state: Dict[str, Any]) -> str:
    verdict = state.get('category_identification_guardrail_verdict', 'PASS')
    retries = state.get('category_identification_retry_count', 0)
    max_retries = self.config.get('workflow', {}).get('max_retries', 2)
    
    if verdict == 'PASS':
        return 'proceed'  # Go to next stage
    elif retries < max_retries:
        return 'retry'    # Run main agent again with feedback
    else:
        return 'proceed'  # Max retries reached, move on
```

### Feedback Loop

On retry, the guardrail's feedback is passed to the main agent:

```python
# In main agent's build_input()
feedback = state.get('category_identification_guardrail_feedback', '')
previous_output = state.get('categories_json', '')

if feedback and previous_output:
    input_data['improvement_feedback'] = feedback
    input_data['previous_output'] = previous_output
```

The LLM then receives a multi-turn conversation with the previous attempt and feedback.

---

## Adding New Agents

### Step 1: Create Agent Class

```python
# copy_gen/agents/my_new_agent.py

from .base import BaseAgent

class MyNewAgent(BaseAgent):
    
    @property
    def agent_name(self) -> str:
        return 'my_new_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {
            'canonical_query': state.get('query', ''),
            # Add other inputs from state
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        # Parse LLM result
        my_output = result.get('my_output', '')
        
        return {
            'my_output': my_output,
            '_validation_result': {'step': 'my_new_agent', 'output': my_output}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        self.log_info("Running my new agent...")
        updates = self.run(state)
        
        new_state = dict(state)
        new_state['my_output'] = updates['my_output']
        new_state['my_new_agent_time'] = updates['_time_taken']
        
        return new_state
```

### Step 2: Create Prompt Template

```text
# prompts/my_new_agent.txt

You are a My New Agent for an e-commerce retailer.

TASK
Do something useful with the query.

INPUT FORMAT
You will receive a JSON object with:
- canonical_query: The original user query

OUTPUT
Return VALID JSON with exactly one key:
{"my_output": "<your output here>"}
```

### Step 3: Register Agent

```python
# copy_gen/agents/__init__.py

from .my_new_agent import MyNewAgent, MyNewAgentGuardrailAgent

__all__ = [
    # ... existing agents
    'MyNewAgent',
    'MyNewAgentGuardrailAgent',
]
```

### Step 4: Add to Workflow

```python
# copy_gen/core/workflow.py

def _build_graph(self):
    # Add node
    self.graph.add_node("my_new_agent", self.my_new_agent)
    
    # Add edge
    self.graph.add_edge("previous_stage", "my_new_agent")
    self.graph.add_edge("my_new_agent", "next_stage")
```

### Step 5: Update Config

```yaml
# conf.yml

agents:
  my_new_agent:
    model: "gpt-4.1-mini"
    temperature: 0.8
    max_tokens: 1024

prompts:
  agents:
    my_new_agent: "my_new_agent.txt"
```

---

## Configuration System

### Config Loading

```python
from copy_gen.config import load_config

config = load_config('conf.yml')
```

### Agent-Specific Settings

The LLM client loads per-agent settings:

```python
# In llm.py
def _get_agent_config(self, agent_name: str) -> Dict[str, Any]:
    agents_config = self.config.get('agents', {})
    agent_config = agents_config.get(agent_name, {})
    
    return {
        'model': agent_config.get('model', default_model),
        'temperature': agent_config.get('temperature', default_temp),
        'max_tokens': agent_config.get('max_tokens', default_tokens),
    }
```

### Prompt Loading

Prompts are loaded by agent name from the config:

```yaml
prompts:
  dir: "prompts"
  agents:
    query_normalizer_agent: "query_normalizer.txt"
    category_identification_agent: "category_identification.txt"
```

---

## Summary

| Concept | Implementation |
|---------|---------------|
| **State Management** | GraphState TypedDict, shared across all agents |
| **Agent Communication** | Agents read/write to state, no direct agent-to-agent calls |
| **LLM Calls** | AgentAPIClient handles all API communication |
| **Message Format** | System prompt + Task instructions + JSON input |
| **Validation** | Guardrail agents check output, trigger retries |
| **Configuration** | All settings in conf.yml, per-agent overrides supported |
