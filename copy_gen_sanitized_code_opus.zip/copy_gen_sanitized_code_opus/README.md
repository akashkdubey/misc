# Copy Block Generator

A 4-stage agentic pipeline for generating SEO-optimized marketing copy for e-commerce product grids. Built with LangGraph for workflow orchestration and includes guardrail agents for quality control.

## 🎯 What It Does

Given a user search query like **"living room ideas"**, the system:

1. **Normalizes** it to a shoppable phrase → "living room furniture"
2. **Identifies** 4-8 relevant product categories → Sofas, Coffee Tables, Accent Chairs...
3. **Expands** into 6-12 shopper-friendly search queries (fanouts) → "comfortable sofas for small spaces"
4. **Writes** a 100-120 word marketing paragraph for the product grid

Each stage has a **guardrail agent** that validates output and triggers retries if quality checks fail.

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure

Edit `conf.yml` with your LLM API settings:

```yaml
llm:
  base_url: "https://your-llm-api.com/v1"
  api_key: "YOUR_API_KEY"
  timeout: 60
```

### 3. Run

```bash
# Single keyword (with live API)
python -m copy_gen.cli run "outdoor patio furniture"

# Single keyword (mock mode - no API calls)
python -m copy_gen.cli run "outdoor patio furniture" --mock

# Batch processing
python -m copy_gen.cli batch data/sample_50_keywords.csv --output-dir results
```

---

## 💻 CLI Commands

### `run` - Single Keyword

```bash
python -m copy_gen.cli run "your search query" [options]
```

| Option | Description |
|--------|-------------|
| `--mock` | Run in offline mode with mock responses |
| `--output-dir DIR` | Directory for output files (default: `output`) |
| `--config FILE` | Custom config file (default: `conf.yml`) |
| `--log-dir DIR` | Directory for log files (default: `logs`) |
| `--verbose` | Enable debug logging |

### `batch` - Multiple Keywords

```bash
python -m copy_gen.cli batch INPUT_FILE [options]
```

**Input file formats:**
- **CSV**: Should have a column named `keyword`, `query`, or be a single column
- **TXT**: One keyword per line

---

## 📁 Output Structure

All outputs are saved in a **timestamp-named folder** for easy management:

```
output/
└── 20260206_143639/           # ← Timestamp folder
    ├── result.json            # Full pipeline result
    ├── result.csv             # Flattened for analysis
    └── result.xlsx            # Styled spreadsheet
```

For batch processing:
```
output/
└── 20260206_143639/
    ├── batch_report.json
    ├── batch_report.csv
    └── batch_report.xlsx
```

---

## 📊 Output Fields

| Field | Description |
|-------|-------------|
| `query` | Original input query |
| `normalized_query` | Shoppable phrase (Stage 1 output) |
| `categories` | Selected product categories with scores and rationale |
| `fanout_output.fanouts` | Array of search queries for product aisles |
| `final_copy` | Marketing paragraph (100-120 words) |
| `*_guardrail_verdict` | PASS/FAIL/NEEDS_REVIEW for each stage |
| `*_retries` | Number of retry attempts per stage |
| `total_time` | End-to-end execution time |

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CopyBlockWorkflow                             │
│                         (LangGraph Orchestrator)                        │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        ▼                           ▼                           ▼
┌───────────────┐           ┌───────────────┐           ┌───────────────┐
│   Stage 1     │           │   Stage 2     │           │   Stage 3     │
│    Query      │ ────────► │   Category    │ ────────► │    Fanout     │
│  Normalizer   │           │ Identification│           │   Expansion   │
└───────────────┘           └───────────────┘           └───────────────┘
        │                           │                           │
        ▼                           ▼                           ▼
┌───────────────┐           ┌───────────────┐           ┌───────────────┐
│   Guardrail   │           │   Guardrail   │           │   Guardrail   │
│   (QA Agent)  │           │   (QA Agent)  │           │   (QA Agent)  │
└───────────────┘           └───────────────┘           └───────────────┘
        │                           │                           │
        └───────────────────────────┼───────────────────────────┘
                                    ▼
                            ┌───────────────┐
                            │   Stage 4     │
                            │  Marketing    │
                            │    Copy       │
                            └───────────────┘
                                    │
                                    ▼
                            ┌───────────────┐
                            │   Guardrail   │
                            │   (QA Agent)  │
                            └───────────────┘
                                    │
                                    ▼
                              Final Output
```

### How Data Flows Between Agents

All agents communicate through a **shared state dictionary** managed by LangGraph:

```python
# State flows like this:
state = {
    'query': 'living room ideas',              # Input
    'normalized_query': 'living room',         # Stage 1 writes
    'categories': [...],                       # Stage 2 writes
    'fanout_output': {'fanouts': [...]},       # Stage 3 writes
    'final_copy': '...',                       # Stage 4 writes
}
```

Each agent:
1. **`build_input(state)`** - Reads what it needs from state, packages as JSON for LLM
2. **Calls LLM** - System prompt + Input data (as separate JSON message)
3. **`process_output(result, state)`** - Parses LLM response, returns state updates

The workflow applies these updates and passes the state to the next agent.

---

## 📂 Project Structure

```
copy_gen_sanitized_code/
├── conf.yml                    # All configuration knobs
├── README.md                   # This file
├── ARCHITECTURE.md             # Detailed technical docs
├── requirements.txt
│
├── data/
│   ├── item_types.json         # Product category catalog
│   └── sample_50_keywords.csv  # Sample batch input
│
├── prompts/                    # LLM prompt templates
│   ├── query_normalizer.txt
│   ├── query_normalizer_guardrail.txt
│   ├── category_identification.txt
│   ├── category_identification_guardrail.txt
│   ├── fanout_expansion.txt
│   ├── fanout_expansion_guardrail.txt
│   ├── marketing_copy.txt
│   └── marketing_copy_guardrail.txt
│
└── copy_gen/
    ├── cli.py                  # Command-line interface
    ├── config.py               # Config loader
    │
    ├── agents/                 # All 8 agent classes
    │   ├── base.py             # BaseAgent abstract class
    │   ├── query_normalizer.py
    │   ├── category_identification.py
    │   ├── fanout_expansion.py
    │   └── marketing_copy.py
    │
    ├── clients/
    │   └── llm.py              # LLM API client
    │
    ├── core/
    │   ├── state.py            # GraphState definition
    │   └── workflow.py         # LangGraph workflow
    │
    └── utils/
        ├── guardrails.py       # Validation utilities
        ├── mocks.py            # Mock mode implementation
        ├── output_formatter.py # JSON/CSV/Excel export
        └── logging.py          # Logging setup
```

---

## ⚙️ Configuration (`conf.yml`)

### Key Sections

```yaml
# LLM API settings
llm:
  base_url: "https://your-api.com/v1"
  api_key: "YOUR_KEY"
  timeout: 60
  max_retries: 3

# Per-agent LLM tuning
agents:
  default:
    model: "gpt-4.1-mini"
    temperature: 1.0
    max_tokens: 1024
  
  query_normalizer_agent:
    temperature: 0.7     # Lower for consistency
  
  marketing_copy_agent:
    temperature: 0.9     # Higher for creativity

# Workflow settings
workflow:
  system_prompt: "You are a helpful assistant..."

# Guardrail behavior
guardrails:
  # Enable/disable per stage
  query_normalizer_guardrail_enabled: true
  category_identification_guardrail_enabled: true
  
  # Max retries
  query_normalizer_max_retries: 2
```

---

## 🧪 Development & Testing

### Mock Mode

Test the full pipeline without API calls:

```bash
python -m copy_gen.cli run "test query" --mock
```

Mock mode uses predefined responses in `copy_gen/utils/mocks.py`.

### Adding a New Agent

1. Create agent class extending `BaseAgent` in `copy_gen/agents/`
2. Implement `agent_name`, `build_input()`, `process_output()`, `__call__()`
3. Create prompt template in `prompts/`
4. Register in `copy_gen/agents/__init__.py`
5. Add to workflow graph in `copy_gen/core/workflow.py`

---

## 🔍 Debugging

### View Logs

Logs are saved to `logs/copy_gen_YYYYMMDD_HHMMSS.log`:

```bash
tail -f logs/copy_gen_*.log
```

### Verbose Mode

```bash
python -m copy_gen.cli run "test" --verbose
```

### Check Individual Stage

Look at the JSON output for detailed stage-by-stage results:

```bash
cat output/20260206_143639/result.json | jq '.categories'
```

---

## 📝 License

Internal use only.
