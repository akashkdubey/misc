# Copy Block Generator

A powerful tool for generating SEO-optimized marketing copy with built-in guardrails and validation.

## 🚀 Setup

### 1. Prerequisites
- Python 3.8+
- Access to Target's Internal LLM API (unless using mock mode)

### 2. Installation
Install dependencies:
```bash
pip install -r requirements.txt
```

### 3. Configuration
Ensure you have a `conf.yml` file with your API credentials and path settings.
```yaml
llm:
  api_key: "YOUR_KEY"
  endpoint: ""

data_paths:
  item_types: "data/item_types.json"
```

---

## 💻 Usage

The tool provides a comprehensive CLI for both single-query generation and batch processing.

### Run Single Keyword
Generate copy for a specific keyword.

```bash
python -m copy_gen.cli run "office desk" --output-dir my_results
```

**Options:**
- `--mode`: Select generation strategy.
  - `v1`: Constrained mode (direct validation).
  - `v2`: Unconstrained brainstorming + Filtering (better for creative discovery).
- `--mock`: Run in offline mock mode (no API calls).
- `--output-dir`: Directory to save JSON/CSV/Excel reports.

**Example (V2 Mode with Mocking):**
```bash
python -m copy_gen.cli run "mid century modern chair" --mode v2 --mock --output-dir output_test
```

### Run Batch Processing
Process a list of keywords from a CSV or Text file.

```bash
# If 'batch_processing.input_file' is set in conf.yml:
python -m copy_gen.cli batch --output-dir batch_results

# Or specify logic file explicitly:
python -m copy_gen.cli batch keywords.csv --output-dir batch_results
```

**Input Format:**
- **CSV**: Should have a column named `keyword`, `query`, or be a single column.
- **TXT**: One keyword per line.

**Batch Output:**
The tool generates a **consolidated report** (Excel `.xlsx` and CSV `.csv`) in the output directory.
- **Excel Report**: Includes formatting, color-coded validation scores, and detailed logs.
- **CSV Report**: Flattened structure for easy data analysis.

---

## 📊 Output Format

For every run (single or batch), the tool generates detailed artifacts:

1.  **Excel Report (`.xlsx`)**:
    *   **Main Query**: The input intent.
    *   **Valid Fanouts**: List of generated queries that passed filtering.
    *   **Rejected Fanouts**: Queries rejected by guardrails with reasons.
    *   **Copy Text**: Final generated marketing copy.
    *   **Validation Log**: Step-by-step pass/fail logs for each guardrail.
    *   **Scores**: Quality scores for fanout and copy stages.

2.  **CSV Report (`.csv`)**:
    *   Flattened version of the above, suitable for programmatic analysis.

3.  **JSON (`.json`)**:
    *   Full raw data including intermediate states and API responses.

---

## 🛠️ Project Structure

- `copy_gen/`: Main source code.
  - `agents/`: Modular agents (Fanout, Copy, Guardrails).
  - `core/`: State management and Workflow orchestration.
  - `utils/`: Validators, formatters, and helpers.
- `data/`: Configuration files and item type definitions.
- `prompts/`: Text prompts for LLM agents.
- `logs/`: Execution logs for debugging.

## 🧪 Testing

To verify the setup without hitting the API:
```bash
python -m copy_gen.cli run "test keyword" --mock
```
