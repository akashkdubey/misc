"""
Copy Generator Agent - Creates marketing copy from fanouts.
"""

import json
import logging
from typing import Dict, Any

from .base import BaseAgent
from ..utils.guardrails import validate_copy_output

logger = logging.getLogger(__name__)


class CopyGeneratorAgent(BaseAgent):
    """Generate SEO marketing copy from fanouts."""
    
    @property
    def agent_name(self) -> str:
        return 'copy_generator_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        input_data = {"fanout_agent_output_json": state['fanout_output_json']}
        
        # On retry, include feedback and previous output
        feedback = state.get('copy_guardrail_feedback', '')
        previous_copy = state.get('final_copy', '')
        
        if feedback and previous_copy:
            input_data["improvement_feedback"] = feedback
            input_data["previous_output"] = json.dumps({"copy": previous_copy})
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        retry_count = state.get('copy_retry_count', 0)
        final_copy = result.get('copy', '')
        
        # Validate
        must_cover = state.get('fanout_output', {}).get('must_cover', [])
        validation = validate_copy_output(
            result,
            must_cover_terms=must_cover,
            config=self.guardrails_config
        )
        
        self.log_info(f"Copy validation: score={validation.score:.1f}")
        for w in validation.warnings:
            self.log_warning(w)
        
        step_name = f"copy_generator{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        return {
            'final_copy': final_copy,
            '_validation_result': {"step": step_name, **validation.to_dict()}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('copy_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Copy Generation: RETRY {retry_count}")
        else:
            self.log_info("Copy Generation: Creating marketing copy...")
        
        updates = self.run(state)
        
        new_state = self.apply_updates(state, updates)
        new_state['copy_time'] = state.get('copy_time', 0) + updates['_time_taken']
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state
