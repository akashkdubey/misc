
from unittest.mock import MagicMock
from ..clients.llm import AgentAPIClient

# Track call counts for simulating retries
_call_counts = {}

def apply_mocks():
    """
    Apply mocks for AgentAPIClient to avoid live API calls.
    Simulates two-stage guardrails with fanout and copy validation.
    """
    global _call_counts
    _call_counts = {}
    
    def mock_call_agent(agent_name, input_data):
        _call_counts[agent_name] = _call_counts.get(agent_name, 0) + 1
        call_num = _call_counts[agent_name]
        
        # FANOUT AGENTS
        if 'fanout' in agent_name and 'guardrail' not in agent_name:
            if 'v1' in agent_name:
                # First call: fewer fanouts, second call: more
                if call_num == 1:
                    return {
                        "reasoning": "Mock V1 - initial fanout generation",
                        "selected_item_types": ["Sofas", "Coffee Tables"],
                        "fanouts": [
                            {"query": "sectional sofas", "type": "Sofas"},
                            {"query": "glass coffee tables", "type": "Coffee Tables"}
                        ],
                        "must_cover": ["sectional sofas"]
                    }, 1.5
                else:
                    return {
                        "reasoning": "Mock V1 - improved fanouts after feedback",
                        "selected_item_types": ["Sofas", "Coffee Tables", "Accent Chairs", "Floor Lamps"],
                        "fanouts": [
                            {"query": "comfortable sofas for small spaces", "type": "Sofas"},
                            {"query": "modern coffee tables", "type": "Coffee Tables"},
                            {"query": "accent chairs under 200", "type": "Accent Chairs"},
                            {"query": "floor lamps for reading", "type": "Floor Lamps"},
                            {"query": "sectional sofas for apartments", "type": "Sofas"},
                            {"query": "wooden coffee tables", "type": "Coffee Tables"},
                            {"query": "velvet accent chairs", "type": "Accent Chairs"},
                            {"query": "mid-century floor lamps", "type": "Floor Lamps"},
                            {"query": "leather sofas", "type": "Sofas"},
                            {"query": "round coffee tables", "type": "Coffee Tables"}
                        ],
                        "must_cover": ["comfortable sofas for small spaces", "modern coffee tables"]
                    }, 1.5
            elif 'v2_generate' in agent_name:
                return {
                    "brainstorming_process": "Exploring living room categories...",
                    "fanouts": ["sectional sofas", "glass coffee tables", "floor lamps", "area rugs", "accent chairs"]
                }, 1.2
            elif 'v2_filter' in agent_name:
                return {
                    "validation_logic": "Filtered against inventory...",
                    "valid_fanouts": [
                        {"query": "sectional sofas", "mapped_type": "Sofas"},
                        {"query": "glass coffee tables", "mapped_type": "Coffee Tables"}
                    ],
                    "must_cover": ["sectional sofas"]
                }, 0.8
        
        # FANOUT GUARDRAIL
        elif 'fanout_guardrail' in agent_name:
            if call_num == 1:
                # First check: needs more fanouts
                return {
                    "relevance_check": {"passed": True, "feedback": "Fanouts are relevant"},
                    "quality_check": {"passed": False, "score": 55, "feedback": "Only 2 fanouts - need at least 10"},
                    "coverage_check": {"passed": False, "missing_angles": ["styles", "features"], "feedback": "Missing style and feature dimensions"},
                    "overall_verdict": "NEEDS_REVIEW",
                    "improvement_suggestions": ["Generate more fanouts (target 6-10)", "Add style variations", "Add feature-based queries"]
                }, 1.0
            else:
                return {
                    "relevance_check": {"passed": True, "feedback": "All fanouts match query intent"},
                    "quality_check": {"passed": True, "score": 88, "feedback": "Good variety of 10 fanouts"},
                    "coverage_check": {"passed": True, "missing_angles": [], "feedback": "Good coverage"},
                    "overall_verdict": "PASS",
                    "improvement_suggestions": []
                }, 1.0
        
        # COPY GENERATOR
        elif 'copy_generator' in agent_name:
            if call_num == 1:
                return {
                    "copy": "Transform your living space with our curated selection of living room essentials. Whether you're setting up your first apartment or redesigning an established home, our diverse collection has everything you need to create the perfect gathering space. From plush sectional sofas ideal for relaxing with loved ones to elegant accent chairs that add personality to any corner, we offer furniture for every lifestyle. Our selection includes pieces in various styles, from sleek minimalist designs to warm rustic aesthetics that bring character to your home. Browse through our carefully curated options featuring durable fabrics perfect for families with kids or pets, as well as premium leather pieces for those seeking a touch of luxury. We also carry an extensive range of occasional tables, storage solutions, and decorative lighting to complete your living room vision. With options at every price point, creating a beautiful and functional living space has never been easier or more accessible."
                }, 2.0
            else:
                return {
                    "copy": "Transform your living space with comfortable sofas for small spaces and modern coffee tables that blend style with function. Whether you're furnishing a cozy apartment or refreshing a spacious family room, our collection offers something for every taste and budget. Explore plush sectional sofas for apartments perfect for movie nights, or discover sleek glass coffee tables that add contemporary elegance. For those who love mid-century aesthetics, browse our velvet accent chairs with clean lines and warm wood tones. Pet owners will appreciate our easy-clean fabric options, while minimalists can explore streamlined furniture pieces that maximize space. From farmhouse-inspired wooden coffee tables to luxurious leather sofas, our living room furniture covers every style imaginable. Complete your space with mid-century floor lamps for reading and decorative accents that tie the room together. Whether you prefer bold statement pieces or subtle neutral tones, you'll find exactly what you need to create your dream living room."
                }, 2.0
        
        # COPY GUARDRAIL
        elif 'copy_guardrail' in agent_name:
            if call_num == 1:
                return {
                    "safety_check": {"passed": True, "issues": []},
                    "quality_check": {"passed": False, "score": 68, "feedback": "Copy doesn't include must_cover terms"},
                    "relevance_check": {"passed": True, "irrelevant_fanouts": []},
                    "overall_verdict": "NEEDS_REVIEW",
                    "improvement_suggestions": ["Include 'comfortable sofas for small spaces'", "Include 'modern coffee tables'"]
                }, 1.0
            else:
                return {
                    "safety_check": {"passed": True, "issues": []},
                    "quality_check": {"passed": True, "score": 92, "feedback": "Excellent copy with all keywords covered"},
                    "relevance_check": {"passed": True, "irrelevant_fanouts": []},
                    "overall_verdict": "PASS",
                    "improvement_suggestions": []
                }, 1.0
            
        return {}, 0.0
        
    AgentAPIClient.call_agent_api = MagicMock(side_effect=mock_call_agent)
