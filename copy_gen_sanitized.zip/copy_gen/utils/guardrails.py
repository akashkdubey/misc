"""
Multi-layer guardrails for validating LLM outputs.

This module provides three validation layers:
1. Structural Validation - JSON schema and required fields
2. Quantity Validation - Counts, ranges, lengths
3. Quality Validation - Semantic relevance, diversity, forbidden phrases
"""

import re
import json
import logging
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Set
from difflib import SequenceMatcher

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of validation with detailed metrics."""
    is_valid: bool
    score: float  # 0-100
    errors: List[str] = field(default_factory=list)  # Critical issues
    warnings: List[str] = field(default_factory=list)  # Non-critical issues
    metrics: Dict[str, Any] = field(default_factory=dict)  # Detailed metrics

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "score": self.score,
            "errors": self.errors,
            "warnings": self.warnings,
            "metrics": self.metrics
        }


# =============================================================================
# Layer 1: Structural Validation
# =============================================================================

def sanitize_json_response(raw_text: str) -> Optional[Dict[str, Any]]:
    """
    Extract JSON from raw LLM response which may be wrapped in markdown code blocks.
    
    Handles:
    - ```json ... ```
    - ``` ... ```
    - Raw JSON
    - JSON with leading/trailing text
    """
    if not raw_text:
        return None
    
    text = raw_text.strip()
    
    # Try to extract from markdown code blocks
    patterns = [
        r'```json\s*([\s\S]*?)\s*```',  # ```json ... ```
        r'```\s*([\s\S]*?)\s*```',       # ``` ... ```
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            text = match.group(1).strip()
            break
    
    # Try to find JSON object boundaries
    if not text.startswith('{'):
        start = text.find('{')
        if start != -1:
            text = text[start:]
    
    if not text.endswith('}'):
        end = text.rfind('}')
        if end != -1:
            text = text[:end + 1]
    
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse JSON: {e}")
        return None


def validate_required_fields(data: Dict[str, Any], required: List[str]) -> List[str]:
    """Check that all required fields are present."""
    errors = []
    for field_name in required:
        if field_name not in data:
            errors.append(f"Missing required field: '{field_name}'")
        elif data[field_name] is None:
            errors.append(f"Field '{field_name}' is null")
    return errors


# =============================================================================
# Layer 2: Quantity & Range Validation
# =============================================================================

def check_fanout_count(
    fanouts: List[Any],
    min_count: int = 25,
    max_count: int = 30
) -> tuple[bool, List[str], List[str]]:
    """
    Validate fanout count is within acceptable range.
    
    Returns: (is_valid, errors, warnings)
    """
    errors = []
    warnings = []
    count = len(fanouts) if fanouts else 0
    
    if count == 0:
        errors.append("No fanouts generated")
    elif count < min_count:
        warnings.append(f"Low fanout count: {count} (minimum recommended: {min_count})")
    elif count > max_count:
        warnings.append(f"High fanout count: {count} (maximum recommended: {max_count})")
    
    is_valid = len(errors) == 0
    return is_valid, errors, warnings


def check_weight_ranges(fanouts: List[Dict[str, Any]]) -> List[str]:
    """Validate all weights are between 0.0 and 1.0."""
    warnings = []
    for i, f in enumerate(fanouts):
        weight = f.get('weight')
        if weight is not None:
            if not isinstance(weight, (int, float)):
                warnings.append(f"Fanout {i}: weight is not a number")
            elif weight < 0.0 or weight > 1.0:
                warnings.append(f"Fanout {i}: weight {weight} outside valid range [0, 1]")
    return warnings


def check_copy_length(
    copy_text: str,
    min_words: int = 30,
    max_words: int = 150
) -> tuple[bool, List[str], List[str]]:
    """
    Validate copy text length.
    
    Returns: (is_valid, errors, warnings)
    """
    errors = []
    warnings = []
    
    if not copy_text:
        errors.append("Copy text is empty")
        return False, errors, warnings
    
    word_count = len(copy_text.split())
    
    if word_count < min_words:
        warnings.append(f"Copy is too short: {word_count} words (minimum: {min_words})")
    elif word_count > max_words:
        warnings.append(f"Copy is too long: {word_count} words (maximum: {max_words})")
    
    return True, errors, warnings


# =============================================================================
# Layer 3: Quality & Semantic Validation
# =============================================================================

def check_fanout_relevance(
    fanouts: List[Any],
    original_query: str,
    min_relevance_ratio: float = 0.3
) -> tuple[float, List[str]]:
    """
    Check how many fanouts appear relevant to the original query.
    
    Returns: (relevance_score 0-1, warnings)
    """
    if not fanouts or not original_query:
        return 0.0, ["Cannot check relevance: missing fanouts or query"]
    
    query_words = set(original_query.lower().split())
    relevant_count = 0
    warnings = []
    
    for f in fanouts:
        # Handle both string fanouts and dict fanouts
        fanout_text = f.get('query', f) if isinstance(f, dict) else str(f)
        fanout_words = set(fanout_text.lower().split())
        
        # Check if at least one query word appears in fanout
        if query_words & fanout_words:
            relevant_count += 1
    
    relevance_ratio = relevant_count / len(fanouts)
    
    if relevance_ratio < min_relevance_ratio:
        warnings.append(
            f"Low relevance: only {relevant_count}/{len(fanouts)} fanouts "
            f"({relevance_ratio:.0%}) contain query terms"
        )
    
    return relevance_ratio, warnings


def check_fanout_diversity(
    fanouts: List[Any],
    similarity_threshold: float = 0.8
) -> tuple[float, List[str]]:
    """
    Check fanout diversity by detecting near-duplicates.
    
    Returns: (diversity_score 0-1, warnings)
    """
    if not fanouts or len(fanouts) < 2:
        return 1.0, []
    
    warnings = []
    duplicates_found = 0
    seen_fanouts: Set[str] = set()
    
    fanout_texts = []
    for f in fanouts:
        text = f.get('query', f) if isinstance(f, dict) else str(f)
        text = text.lower().strip()
        fanout_texts.append(text)
        
        # Exact duplicate check
        if text in seen_fanouts:
            duplicates_found += 1
            warnings.append(f"Duplicate fanout: '{text}'")
        seen_fanouts.add(text)
    
    # Near-duplicate check (pairwise similarity)
    near_duplicates = 0
    for i in range(len(fanout_texts)):
        for j in range(i + 1, len(fanout_texts)):
            similarity = SequenceMatcher(None, fanout_texts[i], fanout_texts[j]).ratio()
            if similarity >= similarity_threshold:
                near_duplicates += 1
    
    total_pairs = len(fanout_texts) * (len(fanout_texts) - 1) / 2
    diversity_score = 1.0 - (near_duplicates / total_pairs) if total_pairs > 0 else 1.0
    
    if near_duplicates > 0:
        warnings.append(f"Found {near_duplicates} near-duplicate fanout pairs")
    
    return diversity_score, warnings


def check_copy_quality(
    copy_text: str,
    must_cover_terms: List[str]
) -> tuple[float, List[str]]:
    """
    Check if copy includes required keywords from must_cover.
    
    Returns: (coverage_score 0-1, warnings)
    """
    if not copy_text or not must_cover_terms:
        return 1.0, []
    
    warnings = []
    copy_lower = copy_text.lower()
    covered_count = 0
    
    for term in must_cover_terms:
        if term.lower() in copy_lower:
            covered_count += 1
        else:
            warnings.append(f"Copy missing required term: '{term}'")
    
    coverage_score = covered_count / len(must_cover_terms) if must_cover_terms else 1.0
    return coverage_score, warnings


def check_profanity_nsfw(
    text: str,
    custom_blocklist: List[str] = None
) -> tuple[bool, List[str]]:
    """
    Check text for profanity, NSFW content, and inappropriate language.
    
    This is a rule-based pre-filter. For comprehensive NSFW detection,
    use the LLM-based guardrail_agent.
    
    Returns: (is_clean, issues)
    """
    # Common profanity and inappropriate terms (case-insensitive)
    # This is a basic blocklist - the LLM guardrail agent provides deeper analysis
    default_blocklist = [
        # Profanity
        "fuck", "shit", "damn", "ass", "bitch", "bastard", "crap",
        "hell", "piss", "dick", "cock", "pussy", "whore", "slut",
        # Slurs and hate speech indicators
        "nigger", "faggot", "retard", "spic", "chink", "kike",
        # Violence
        "kill", "murder", "rape", "abuse", "torture",
        # NSFW indicators
        "porn", "xxx", "nude", "naked", "sex", "erotic", "fetish",
        # Other inappropriate
        "drug", "cocaine", "heroin", "meth",
    ]
    
    blocklist = (custom_blocklist or []) + default_blocklist
    
    issues = []
    text_lower = text.lower() if text else ""
    
    for term in blocklist:
        # Use word boundary matching to avoid false positives
        # e.g., "class" shouldn't match "ass"
        import re
        pattern = r'\b' + re.escape(term.lower()) + r'\b'
        if re.search(pattern, text_lower):
            issues.append(f"Inappropriate content detected: '{term}'")
    
    return len(issues) == 0, issues


def check_content_safety(
    copy_text: str,
    fanouts: List[Any] = None,
    config: Dict[str, Any] = None
) -> tuple[bool, List[str], List[str]]:
    """
    Comprehensive content safety check for copy and fanouts.
    
    Returns: (is_safe, errors, warnings)
    """
    config = config or {}
    custom_blocklist = config.get('safety', {}).get('blocklist', [])
    
    errors = []
    warnings = []
    
    # Check copy text
    if copy_text:
        is_clean, copy_issues = check_profanity_nsfw(copy_text, custom_blocklist)
        if not is_clean:
            errors.extend([f"Copy: {issue}" for issue in copy_issues])
    
    # Check fanout queries
    if fanouts:
        for i, f in enumerate(fanouts):
            fanout_text = f.get('query', f) if isinstance(f, dict) else str(f)
            is_clean, fanout_issues = check_profanity_nsfw(fanout_text, custom_blocklist)
            if not is_clean:
                errors.extend([f"Fanout {i}: {issue}" for issue in fanout_issues])
    
    is_safe = len(errors) == 0
    return is_safe, errors, warnings


# =============================================================================
# High-Level Validators
# =============================================================================

def validate_fanout_v1_output(
    data: Dict[str, Any],
    original_query: str = "",
    config: Dict[str, Any] = None
) -> ValidationResult:
    """Validate V1 constrained fanout agent output."""
    config = config or {}
    fanout_config = config.get('fanout', {})
    
    errors = []
    warnings = []
    metrics = {}
    
    # Layer 1: Structure
    required = ["reasoning", "selected_item_types", "fanouts"]
    errors.extend(validate_required_fields(data, required))
    
    fanouts = data.get('fanouts', [])
    metrics['fanout_count'] = len(fanouts)
    
    if errors:
        return ValidationResult(is_valid=False, score=0, errors=errors, metrics=metrics)
    
    # Layer 2: Quantity (V1 should produce 6-10 high-quality fanouts)
    min_count = fanout_config.get('min_count', 6)
    max_count = fanout_config.get('max_count', 10)
    is_valid, count_errors, count_warnings = check_fanout_count(fanouts, min_count, max_count)
    errors.extend(count_errors)
    warnings.extend(count_warnings)
    warnings.extend(check_weight_ranges(fanouts))
    
    # Layer 3: Quality
    relevance_score, relevance_warnings = check_fanout_relevance(fanouts, original_query)
    warnings.extend(relevance_warnings)
    metrics['relevance_score'] = relevance_score
    
    diversity_score, diversity_warnings = check_fanout_diversity(fanouts)
    warnings.extend(diversity_warnings)
    metrics['diversity_score'] = diversity_score
    
    # Calculate overall score
    score = calculate_fanout_score(metrics, fanout_config)
    metrics['overall_score'] = score
    
    is_valid = len(errors) == 0 and score >= fanout_config.get('min_score_to_pass', 50)
    
    return ValidationResult(
        is_valid=is_valid,
        score=score,
        errors=errors,
        warnings=warnings,
        metrics=metrics
    )


def validate_fanout_v2_generate_output(
    data: Dict[str, Any],
    original_query: str = "",
    config: Dict[str, Any] = None
) -> ValidationResult:
    """Validate V2 unconstrained generation output."""
    config = config or {}
    
    errors = []
    warnings = []
    metrics = {}
    
    # Layer 1: Structure
    required = ["brainstorming_process", "fanouts"]
    errors.extend(validate_required_fields(data, required))
    
    fanouts = data.get('fanouts', [])
    metrics['fanout_count'] = len(fanouts)
    
    if errors:
        return ValidationResult(is_valid=False, score=0, errors=errors, metrics=metrics)
    
    # Layer 2: Quantity (V2 generate should have 25-30, we'll filter to 6-10 later)
    is_valid, count_errors, count_warnings = check_fanout_count(fanouts, min_count=25, max_count=30)
    errors.extend(count_errors)
    warnings.extend(count_warnings)
    
    # Layer 3: Quality
    diversity_score, diversity_warnings = check_fanout_diversity(fanouts)
    warnings.extend(diversity_warnings)
    metrics['diversity_score'] = diversity_score
    
    score = 70 + (diversity_score * 30)  # Base 70, up to 100 with diversity
    if len(fanouts) < 25:
        score -= 20
    
    return ValidationResult(
        is_valid=len(errors) == 0,
        score=score,
        errors=errors,
        warnings=warnings,
        metrics=metrics
    )


def validate_fanout_v2_filter_output(
    data: Dict[str, Any],
    config: Dict[str, Any] = None
) -> ValidationResult:
    """Validate V2 filter output."""
    config = config or {}
    
    errors = []
    warnings = []
    metrics = {}
    
    # Layer 1: Structure
    required = ["validation_logic", "valid_fanouts"]
    errors.extend(validate_required_fields(data, required))
    
    valid_fanouts = data.get('valid_fanouts', [])
    rejected_fanouts = data.get('rejected_fanouts', [])
    metrics['valid_count'] = len(valid_fanouts)
    metrics['rejected_count'] = len(rejected_fanouts)
    
    if errors:
        return ValidationResult(is_valid=False, score=0, errors=errors, metrics=metrics)
    
    # Layer 2: Quantity (filtered output should be 6-10)
    is_valid, count_errors, count_warnings = check_fanout_count(valid_fanouts, min_count=6, max_count=10)
    errors.extend(count_errors)
    warnings.extend(count_warnings)
    
    # Check mapped_type exists for each valid fanout
    for i, f in enumerate(valid_fanouts):
        if not f.get('mapped_type'):
            warnings.append(f"Valid fanout {i} missing 'mapped_type'")
    
    score = 80 if len(errors) == 0 else 30
    
    return ValidationResult(
        is_valid=len(errors) == 0,
        score=score,
        errors=errors,
        warnings=warnings,
        metrics=metrics
    )


def validate_copy_output(
    data: Dict[str, Any],
    must_cover_terms: List[str] = None,
    config: Dict[str, Any] = None
) -> ValidationResult:
    """Validate copy generator output."""
    config = config or {}
    copy_config = config.get('copy', {})
    must_cover_terms = must_cover_terms or []
    
    errors = []
    warnings = []
    metrics = {}
    
    # Layer 1: Structure
    copy_text = data.get('copy', '')
    if not copy_text:
        errors.append("Missing 'copy' field in response")
        return ValidationResult(is_valid=False, score=0, errors=errors, metrics=metrics)
    
    metrics['word_count'] = len(copy_text.split())
    metrics['char_count'] = len(copy_text)
    
    # Layer 2: Length
    min_words = copy_config.get('min_words', 30)
    max_words = copy_config.get('max_words', 150)
    _, length_errors, length_warnings = check_copy_length(copy_text, min_words, max_words)
    errors.extend(length_errors)
    warnings.extend(length_warnings)
    
    # Layer 3: Safety - Profanity/NSFW check
    custom_blocklist = config.get('safety', {}).get('blocklist', [])
    is_clean, safety_issues = check_profanity_nsfw(copy_text, custom_blocklist)
    if not is_clean:
        errors.extend(safety_issues)  # Safety issues are errors, not warnings
        metrics['safety_passed'] = False
    else:
        metrics['safety_passed'] = True
    
    # Layer 4: Quality - Keyword coverage
    coverage_score, coverage_warnings = check_copy_quality(copy_text, must_cover_terms)
    warnings.extend(coverage_warnings)
    metrics['coverage_score'] = coverage_score
    
    # Score calculation
    score = 50  # Base score
    score += coverage_score * 25  # Up to 25 for keyword coverage
    if is_clean:
        score += 15  # Bonus for passing safety check
    if min_words <= metrics['word_count'] <= max_words:
        score += 10  # Bonus for good length
    
    return ValidationResult(
        is_valid=len(errors) == 0,
        score=min(score, 100),
        errors=errors,
        warnings=warnings,
        metrics=metrics
    )


def calculate_fanout_score(metrics: Dict[str, Any], config: Dict[str, Any]) -> float:
    """Calculate overall fanout quality score."""
    score = 50  # Base score
    
    fanout_count = metrics.get('fanout_count', 0)
    min_count = config.get('min_count', 10)
    max_count = config.get('max_count', 30)
    
    # Count score (up to 20 points)
    if min_count <= fanout_count <= max_count:
        score += 20
    elif fanout_count > 0:
        score += 10
    
    # Relevance score (up to 15 points)
    relevance = metrics.get('relevance_score', 0)
    score += relevance * 15
    
    # Diversity score (up to 15 points)
    diversity = metrics.get('diversity_score', 0)
    score += diversity * 15
    
    return min(score, 100)
