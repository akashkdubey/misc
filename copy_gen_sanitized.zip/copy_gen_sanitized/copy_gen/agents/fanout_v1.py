"""
Fanout V1 Agent - Constrained fanout generation using item types.
"""

import json
import logging
from typing import Dict, Any

from .base import BaseAgent
from ..utils.guardrails import validate_fanout_v1_output

logger = logging.getLogger(__name__)


class FanoutV1Agent(BaseAgent):
    """Generate fanouts constrained by available item types."""
    
    @property
    def agent_name(self) -> str:
        return 'fanout_agent_v1'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        input_data = {
            "query": state['query'],
            "item_types": state['item_types_json']
        }
        
        # On retry, include feedback for multi-turn conversation
        feedback = state.get('fanout_guardrail_feedback', '')
        previous_output = state.get('fanout_output_json', '')
        
        if feedback and previous_output:
            input_data["improvement_feedback"] = feedback
            input_data["previous_output"] = previous_output
        
        return input_data
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        retry_count = state.get('fanout_retry_count', 0)
        
        # Validate output
        validation = validate_fanout_v1_output(
            result, 
            original_query=state['query'], 
            config=self.guardrails_config
        )
        
        self.log_info(f"V1 Fanout validation: score={validation.score:.1f}, valid={validation.is_valid}")
        for w in validation.warnings:
            self.log_warning(w)
        
        step_name = f"fanout_v1{'_retry_' + str(retry_count) if retry_count > 0 else ''}"
        
        return {
            'fanout_output': result,
            'fanout_output_json': json.dumps(result, indent=2),
            '_validation_result': {"step": step_name, **validation.to_dict()}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('fanout_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Fanout V1: RETRY {retry_count}")
        else:
            self.log_info("Step 1 (V1): Generating constrained fanouts...")
        
        updates = self.run(state)
        
        # Build new state (immutable pattern)
        new_state = self.apply_updates(state, updates)
        new_state['fanout_time'] = state.get('fanout_time', 0) + updates['_time_taken']
        
        # Append validation result
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state
