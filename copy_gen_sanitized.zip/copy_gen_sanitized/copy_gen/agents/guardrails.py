"""
Guardrail Agents - Validate fanouts and copy before proceeding.
"""

import logging
from typing import Dict, Any

from .base import BaseAgent

logger = logging.getLogger(__name__)


class FanoutGuardrailAgent(BaseAgent):
    """Validate fanouts before copy generation."""
    
    @property
    def agent_name(self) -> str:
        return 'fanout_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "query": state['query'],
            "fanout_output_json": state['fanout_output_json']
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        verdict = result.get('overall_verdict', 'PASS')
        quality_score = result.get('quality_check', {}).get('score', 0)
        suggestions = result.get('improvement_suggestions', [])
        
        # Build feedback for potential retry
        feedback_parts = []
        for check in ['relevance_check', 'quality_check', 'coverage_check']:
            fb = result.get(check, {}).get('feedback', '')
            if fb:
                feedback_parts.append(f"{check.upper().replace('_CHECK', '')}: {fb}")
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_score': quality_score,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('fanout_retry_count', 0)
        self.log_info(f"Fanout Guardrail: Validating fanouts (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Fanout Guardrail verdict: {updates['_verdict']}, score={updates['_score']}")
        for s in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {s}")
        
        new_state = dict(state)
        new_state['fanout_guardrail_output'] = updates['_output']
        new_state['fanout_guardrail_verdict'] = updates['_verdict']
        new_state['fanout_guardrail_feedback'] = updates['_feedback']
        new_state['fanout_guardrail_time'] = state.get('fanout_guardrail_time', 0) + updates['_time_taken']
        new_state['fanout_retry_count'] = retry_count + 1
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            "step": f"fanout_guardrail_attempt_{retry_count + 1}",
            "is_valid": updates['_verdict'] == 'PASS',
            "score": updates['_score'],
            "errors": [],
            "warnings": updates['_suggestions'],
            "metrics": {"verdict": updates['_verdict'], "score": updates['_score'], "attempt": retry_count + 1}
        })
        new_state['validation_results'] = validation_results
        
        return new_state


class CopyGuardrailAgent(BaseAgent):
    """Validate copy before publishing."""
    
    @property
    def agent_name(self) -> str:
        return 'copy_guardrail_agent'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "query": state['query'],
            "fanout_output_json": state['fanout_output_json'],
            "copy_text": state['final_copy']
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        verdict = result.get('overall_verdict', 'PASS')
        safety_passed = result.get('safety_check', {}).get('passed', True)
        quality_score = result.get('quality_check', {}).get('score', 0)
        suggestions = result.get('improvement_suggestions', [])
        safety_issues = result.get('safety_check', {}).get('issues', [])
        
        # Build feedback
        feedback_parts = []
        if not safety_passed:
            feedback_parts.append(f"SAFETY: {', '.join(safety_issues)}")
        qual_feedback = result.get('quality_check', {}).get('feedback', '')
        if qual_feedback:
            feedback_parts.append(f"QUALITY: {qual_feedback}")
        if suggestions:
            feedback_parts.append(f"SUGGESTIONS: {'; '.join(suggestions)}")
        
        return {
            '_output': result,
            '_verdict': verdict,
            '_safety_passed': safety_passed,
            '_score': quality_score,
            '_feedback': ' | '.join(feedback_parts),
            '_suggestions': suggestions,
            '_safety_issues': safety_issues
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('copy_retry_count', 0)
        self.log_info(f"Copy Guardrail: Validating copy (attempt {retry_count + 1})...")
        
        updates = self.run(state)
        
        self.log_info(f"Copy Guardrail verdict: {updates['_verdict']}, safety={updates['_safety_passed']}, score={updates['_score']}")
        for s in updates['_suggestions']:
            logger.warning(f"  SUGGESTION: {s}")
        
        new_state = dict(state)
        new_state['copy_guardrail_output'] = updates['_output']
        new_state['copy_guardrail_verdict'] = updates['_verdict']
        new_state['copy_guardrail_feedback'] = updates['_feedback']
        new_state['copy_guardrail_time'] = state.get('copy_guardrail_time', 0) + updates['_time_taken']
        new_state['copy_retry_count'] = retry_count + 1
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append({
            "step": f"copy_guardrail_attempt_{retry_count + 1}",
            "is_valid": updates['_verdict'] == 'PASS',
            "score": updates['_score'],
            "errors": updates['_safety_issues'],
            "warnings": updates['_suggestions'],
            "metrics": {"verdict": updates['_verdict'], "safety_passed": updates['_safety_passed'], "score": updates['_score'], "attempt": retry_count + 1}
        })
        new_state['validation_results'] = validation_results
        
        return new_state
