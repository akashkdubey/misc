# Agents module - each agent as a separate class

from .base import BaseAgent
from .fanout_v1 import FanoutV1Agent
from .fanout_v2 import FanoutV2GenerateAgent, FanoutV2FilterAgent
from .copy_generator import CopyGeneratorAgent
from .guardrails import FanoutGuardrailAgent, CopyGuardrailAgent

__all__ = [
    'BaseAgent',
    'FanoutV1Agent',
    'FanoutV2GenerateAgent',
    'FanoutV2FilterAgent',
    'CopyGeneratorAgent',
    'FanoutGuardrailAgent',
    'CopyGuardrailAgent',
]
