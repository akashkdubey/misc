"""
Fanout V2 Agents - Two-stage unconstrained generation and filtering.
"""

import json
import logging
from typing import Dict, Any

from .base import BaseAgent
from ..utils.guardrails import validate_fanout_v2_generate_output, validate_fanout_v2_filter_output

logger = logging.getLogger(__name__)


class FanoutV2GenerateAgent(BaseAgent):
    """Generate unconstrained fanouts through creative brainstorming."""
    
    @property
    def agent_name(self) -> str:
        return 'fanout_agent_v2_generate'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"query": state['query']}
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        validation = validate_fanout_v2_generate_output(
            result,
            original_query=state['query'],
            config=self.guardrails_config
        )
        
        self.log_info(f"V2 Generate validation: score={validation.score:.1f}")
        
        fanouts = result.get('fanouts', [])
        
        return {
            'candidate_fanouts': fanouts,
            'candidate_fanouts_json': json.dumps(fanouts, indent=2),
            '_validation_result': {"step": "fanout_v2_generate", **validation.to_dict()}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        retry_count = state.get('fanout_retry_count', 0)
        
        if retry_count > 0:
            self.log_info(f"Fanout V2 Generate: RETRY {retry_count}")
        else:
            self.log_info("Step 1 (V2): Generating unconstrained fanouts...")
        
        updates = self.run(state)
        
        new_state = self.apply_updates(state, updates)
        new_state['fanout_time'] = state.get('fanout_time', 0) + updates['_time_taken']
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state


class FanoutV2FilterAgent(BaseAgent):
    """Filter fanouts against valid item types."""
    
    @property
    def agent_name(self) -> str:
        return 'fanout_agent_v2_filter'
    
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "candidate_fanouts": state['candidate_fanouts_json'],
            "item_types": state['item_types_json']
        }
    
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        validation = validate_fanout_v2_filter_output(result, config=self.guardrails_config)
        
        self.log_info(f"V2 Filter validation: score={validation.score:.1f}")
        
        valid_fanouts = result.get('valid_fanouts', [])
        must_cover = result.get('must_cover', [])
        
        final_fanout_struct = {
            "canonical_query": state['query'],
            "fanouts": valid_fanouts,
            "must_cover": must_cover
        }
        
        return {
            'fanout_output': final_fanout_struct,
            'fanout_output_json': json.dumps(final_fanout_struct, indent=2),
            '_validation_result': {"step": "fanout_v2_filter", **validation.to_dict()}
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph node function."""
        self.log_info("Step 2 (V2): Filtering fanouts...")
        
        updates = self.run(state)
        
        new_state = self.apply_updates(state, updates)
        new_state['fanout_time'] = state.get('fanout_time', 0) + updates['_time_taken']
        
        validation_results = list(state.get('validation_results', []))
        validation_results.append(updates['_validation_result'])
        new_state['validation_results'] = validation_results
        
        return new_state
