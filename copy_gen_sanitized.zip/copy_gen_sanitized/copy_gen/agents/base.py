"""
Base agent class for all Copy Block agents.
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Any

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Abstract base class for all agents in the Copy Block pipeline.
    
    Each agent implements:
    - agent_name: The name used to look up prompt templates
    - build_input(): Transform graph state into LLM input
    - process_output(): Transform LLM output into state updates
    - __call__(): LangGraph node function (calls run() and applies updates)
    """
    
    def __init__(self, agent_client, config: Dict[str, Any]):
        self.agent_client = agent_client
        self.config = config
        self.guardrails_config = config.get('guardrails', {})
    
    @property
    @abstractmethod
    def agent_name(self) -> str:
        """The agent name used to look up the prompt template."""
        pass
    
    @abstractmethod
    def build_input(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Build the input dict for the LLM call from graph state."""
        pass
    
    @abstractmethod
    def process_output(self, result: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process LLM output and return state updates.
        
        Returns:
            Dict of state keys to update (NOT the full state)
        """
        pass
    
    def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the agent: build input -> call LLM -> process output.
        
        Returns:
            Dict of state updates (includes _time_taken)
        """
        input_data = self.build_input(state)
        result, time_taken = self.agent_client.call_agent_api(self.agent_name, input_data)
        
        updates = self.process_output(result, state)
        updates['_time_taken'] = time_taken
        
        return updates
    
    def apply_updates(self, state: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply updates to state immutably (returns new state dict).
        Filters out internal keys like _time_taken.
        """
        new_state = dict(state)
        for key, value in updates.items():
            if not key.startswith('_'):
                new_state[key] = value
        return new_state
    
    def log_info(self, message: str):
        logger.info(message)
    
    def log_warning(self, message: str):
        logger.warning(f"  - {message}")
