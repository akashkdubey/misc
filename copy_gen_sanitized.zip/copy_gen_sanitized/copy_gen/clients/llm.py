"""Langraph-based Agent client that calls the LLM base URL (chat/completions).

This replaces direct calls to ThinkTank-hosted "agent" endpoints by posting
message payloads to the Langraph/base LLM `chat/completions` endpoint and
extracting JSON content from the LLM response.
"""

import os
import requests
import json
import logging
import time
from typing import Dict, Any, Tuple

from ..utils.guardrails import sanitize_json_response



class AgentAPIClient:
    """Client that sends message-style requests to a base LLM endpoint.

    call_agent_api(agent_name, input_data) remains compatible with existing
    call sites and returns (parsed_result_dict, elapsed_seconds).
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        llm = config.get('llm', {})

        self.base_url = llm.get('base_url')
        if not self.base_url:
            raise ValueError("llm.base_url not configured in conf.yml")

        self.chat_url = f"{self.base_url.rstrip('/')}/chat/completions"
        self.application_name = llm.get('application_name', 'copy_block')
        self.api_key = llm.get('api_key', '')
        self.verify_ssl = llm.get('verify_ssl', True)
        self.timeout = llm.get('timeout', 60)
        self.max_retries = llm.get('max_retries', 3)
        self.reasoning_effort = llm.get('reasoning_effort', 'low')
        # Try to initialize OAuthThinkTank if available for automatic token refresh
        self.oauth_client = None
        # try:
        #     from utils.oauth_thinktank import OAuthThinkTank
        #     self.oauth_client = OAuthThinkTank()
        # except Exception:
        #     self.oauth_client = None

    def _build_messages(self, agent_name: str, input_data: Dict[str, Any]) -> Dict[str, Any]:
        # Build a messages payload. Prompt templates are specified in conf.yml under `prompts`.
        system_prompt = self.config.get('workflow', {}).get('system_prompt', "You are a helpful assistant.")

        prompts_cfg = self.config.get('prompts', {})
        prompts_dir = prompts_cfg.get('dir') or self.config.get('data_paths', {}).get('prompts_dir', 'prompts')
        agent_prompt_file = prompts_cfg.get('agents', {}).get(agent_name) if isinstance(prompts_cfg.get('agents', {}), dict) else None

        prompt_text = None
        if agent_prompt_file:
            prompt_path = f"{prompts_dir.rstrip('/')}/{agent_prompt_file}"
            try:
                with open(prompt_path, 'r', encoding='utf-8') as f:
                    prompt_text = f.read()
            except FileNotFoundError:
                logging.warning(f"Prompt file for {agent_name} not found at {prompt_path}; falling back to flattened input")

        if prompt_text:
            rendered = prompt_text
            # Render common placeholders used across prompts
            replacements = {
                '<<QUERY>>': str(input_data.get('query', '')),
                '<<ITEM_TYPES>>': str(input_data.get('item_types', '')),
                '<<CANDIDATE_FANOUTS>>': str(input_data.get('candidate_fanouts', '')),
                '<<FANOUT_AGENT_OUTPUT_JSON>>': str(input_data.get('fanout_output_json', '')),
                '<<FANOUT_OUTPUT_JSON>>': str(input_data.get('fanout_output_json', '')),
                '<<COPY_TEXT>>': str(input_data.get('copy_text', '')),
            }
            for k, v in replacements.items():
                if k in rendered:
                    rendered = rendered.replace(k, v)

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": rendered}
            ]
            
            # Multi-turn conversation for retry with feedback
            # Instead of polluting the prompt, we use the LLM's conversational capability
            improvement_feedback = input_data.get('improvement_feedback', '')
            previous_output = input_data.get('previous_output', '')
            
            if improvement_feedback and previous_output:
                # Insert the previous attempt and feedback into conversation
                messages.append({"role": "assistant", "content": previous_output})
                messages.append({"role": "user", "content": f"Please revise your output. Issues found:\n{improvement_feedback}"})
            elif improvement_feedback:
                # Just feedback without previous output
                messages.append({"role": "user", "content": f"Please revise. Feedback:\n{improvement_feedback}"})
        else:
            # Fallback: flatten input_data into human-readable content
            content = "\n".join([f"{k}: {v}" for k, v in input_data.items()])
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": content}
            ]

        # Allow per-agent model override in conf (optional)
        agents_cfg = self.config.get('agents', {})
        agent_cfg = agents_cfg.get(agent_name, {}) if isinstance(agents_cfg, dict) else {}
        model = agent_cfg.get('model', agents_cfg.get('model') if isinstance(agents_cfg, dict) else None) or agent_cfg.get('model') or 'gpt-4.1-mini'

        payload = {
            "model": model,
            "messages": messages,
            "temperature": agent_cfg.get('temperature', 1.0),
            "max_new_tokens": agent_cfg.get('max_tokens', agent_cfg.get('max_new_tokens', 1024)),
            "reasoning_effort": agent_cfg.get('reasoning_effort', self.reasoning_effort),
            "stream": False,
        }

        return payload

    def _extract_content(self, resp_json: Dict[str, Any]):
        # Try common response shapes for Target internal API and other LLMs
        # 1) result.output.content
        if isinstance(resp_json, dict):
            if 'output' in resp_json and isinstance(resp_json['output'], dict) and 'content' in resp_json['output']:
                return resp_json['output']['content']

            # 2) data.output.content
            if 'data' in resp_json and isinstance(resp_json['data'], dict):
                out = resp_json['data'].get('output')
                if isinstance(out, dict) and 'content' in out:
                    return out['content']

            # 3) OpenAI/Chat-style: choices[0].message.content
            if 'choices' in resp_json and isinstance(resp_json['choices'], list) and len(resp_json['choices']) > 0:
                ch = resp_json['choices'][0]
                if isinstance(ch, dict):
                    # new style
                    msg = ch.get('message') or ch.get('delta')
                    if isinstance(msg, dict) and 'content' in msg:
                        return msg['content']
                    if 'text' in ch:
                        return ch.get('text')

        # Fallback: return the whole response as a string
        try:
            return json.dumps(resp_json)
        except Exception:
            return str(resp_json)

    def call_agent_api(self, agent_name: str, input_data: Dict[str, Any]) -> Tuple[Dict[str, Any], float]:
        """Send request to the base chat/completions endpoint and return parsed JSON + elapsed time."""
        payload = self._build_messages(agent_name, input_data)

        headers = {
            "Content-Type": "application/json",
            "X-TGT-APPLICATION": self.application_name,
        }
        # Prefer API key header if provided
        if self.api_key:
            headers['x-api-key'] = self.api_key
        else:
            # Determine bearer token: prefer OAuthThinkTank, then BEARER_TOKEN env, then conf.yml
            bearer = None
            if self.oauth_client:
                try:
                    bearer = self.oauth_client.get_oauth_token()
                except Exception as e:
                    logging.warning(f"OAuthThinkTank failed to provide token: {e}")
                    bearer = None

            if not bearer:
                bearer = os.getenv('BEARER_TOKEN') or self.config.get('api', {}).get('agents', {}).get('bearer_token')

            if bearer:
                headers['Authorization'] = f"Bearer {bearer}"

        overall_start = time.time()
        last_error = None

        for attempt in range(1, self.max_retries + 1):
            try:
                logging.info(f"Calling LLM for {agent_name} (attempt {attempt}/{self.max_retries})")
                resp = requests.post(self.chat_url, headers=headers, json=payload, timeout=self.timeout, verify=self.verify_ssl)
                if resp.status_code == 200:
                    resp_json = resp.json()
                    content_str = self._extract_content(resp_json)
                    logging.debug(f"LLM raw content for {agent_name}: {str(content_str)[:2000]}")
                    
                    # Use guardrails to sanitize and parse JSON response
                    parsed_result = None
                    if isinstance(content_str, str):
                        # Try guardrails sanitizer first (handles markdown code blocks)
                        parsed_result = sanitize_json_response(content_str)
                        if parsed_result is None:
                            # Fallback: try direct parse
                            try:
                                parsed_result = json.loads(content_str)
                            except json.JSONDecodeError:
                                # Not JSON, return as text wrapper
                                parsed_result = {"text": content_str}
                                logging.warning(f"LLM response for {agent_name} is not valid JSON")
                    else:
                        parsed_result = content_str

                    logging.info(f"Parsed LLM result for {agent_name}: {type(parsed_result).__name__}")

                    elapsed = time.time() - overall_start
                    return parsed_result, elapsed

                # Retry on transient errors
                if resp.status_code in {429, 500, 502, 503}:
                    wait = 2 ** attempt
                    logging.warning(f"LLM transient status {resp.status_code}, retrying after {wait}s")
                    time.sleep(wait)
                    continue

                # Non-retriable
                logging.error(f"LLM call failed ({resp.status_code}): {resp.text[:1000]}")
                return {}, time.time() - overall_start

            except requests.RequestException as e:
                logging.error(f"LLM request exception: {e}")
                last_error = e
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    break

        raise last_error if last_error else ValueError("LLM call failed after retries")