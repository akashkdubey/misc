"""
GraphState definition for the Copy Block workflow.
"""

import sys
from typing import Dict, Any, List

# TypedDict compatibility
if sys.version_info >= (3, 8):
    from typing import TypedDict
else:
    try:
        from typing_extensions import TypedDict
    except ImportError:
        TypedDict = dict


class GraphState(TypedDict):
    """State that flows through the LangGraph workflow."""
    
    # Input
    query: str
    item_types: list
    item_types_json: str
    
    # Fanout stage outputs
    fanout_output: Dict[str, Any]
    fanout_output_json: str
    candidate_fanouts: list          # V2 intermediate
    candidate_fanouts_json: str
    
    # Copy stage outputs
    copy_output: Dict[str, Any]
    final_copy: str
    
    # Timing metrics
    fanout_time: float
    copy_time: float
    fanout_guardrail_time: float
    copy_guardrail_time: float
    
    # Validation tracking
    validation_results: List[Dict[str, Any]]
    
    # Fanout guardrail state
    fanout_guardrail_output: Dict[str, Any]
    fanout_guardrail_verdict: str
    fanout_guardrail_feedback: str
    fanout_retry_count: int
    
    # Copy guardrail state
    copy_guardrail_output: Dict[str, Any]
    copy_guardrail_verdict: str
    copy_guardrail_feedback: str
    copy_retry_count: int


def create_initial_state(query: str, item_types: list = None) -> GraphState:
    """Create the initial state for a workflow run."""
    import json
    
    return GraphState(
        query=query,
        item_types=item_types or [],
        item_types_json=json.dumps(item_types or []),
        fanout_output={},
        fanout_output_json="",
        candidate_fanouts=[],
        candidate_fanouts_json="[]",
        copy_output={},
        final_copy="",
        fanout_time=0.0,
        copy_time=0.0,
        fanout_guardrail_time=0.0,
        copy_guardrail_time=0.0,
        validation_results=[],
        fanout_guardrail_output={},
        fanout_guardrail_verdict="",
        fanout_guardrail_feedback="",
        fanout_retry_count=0,
        copy_guardrail_output={},
        copy_guardrail_verdict="",
        copy_guardrail_feedback="",
        copy_retry_count=0
    )
