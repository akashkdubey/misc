"""
Copy Block Workflow - Orchestrates agents using LangGraph.
Simplified orchestrator that imports modular agents.
"""

import logging
from typing import Dict, Any

from langgraph.graph import StateGraph, END

from .state import GraphState, create_initial_state
from ..clients.llm import AgentAPIClient
from ..agents.fanout_v1 import FanoutV1Agent
from ..agents.fanout_v2 import FanoutV2GenerateAgent, FanoutV2FilterAgent
from ..agents.copy_generator import CopyGeneratorAgent
from ..agents.guardrails import FanoutGuardrailAgent, CopyGuardrailAgent

logger = logging.getLogger(__name__)


class CopyBlockWorkflow:
    """LangGraph workflow for generating copy blocks with two-stage guardrails."""
    
    def __init__(self, config: Dict[str, Any], mode: str = "v1"):
        self.config = config
        self.mode = mode
        self.agent_client = AgentAPIClient(config)
        
        # Guardrail settings
        guardrail_config = config.get('guardrails', {})
        self.fanout_guardrail_enabled = guardrail_config.get('fanout_guardrail_enabled', True)
        self.copy_guardrail_enabled = guardrail_config.get('copy_guardrail_enabled', True)
        self.fanout_max_retries = guardrail_config.get('fanout_max_retries', 2)
        self.copy_max_retries = guardrail_config.get('copy_max_retries', 2)
        self.retry_on_needs_review = guardrail_config.get('retry_on_needs_review', True)
        
        # Initialize agents
        self._init_agents()
        
        # Build graph
        self.graph = self._build_graph()
    
    def _init_agents(self):
        """Initialize all agent instances."""
        self.fanout_v1 = FanoutV1Agent(self.agent_client, self.config)
        self.fanout_v2_generate = FanoutV2GenerateAgent(self.agent_client, self.config)
        self.fanout_v2_filter = FanoutV2FilterAgent(self.agent_client, self.config)
        self.copy_generator = CopyGeneratorAgent(self.agent_client, self.config)
        self.fanout_guardrail = FanoutGuardrailAgent(self.agent_client, self.config)
        self.copy_guardrail = CopyGuardrailAgent(self.agent_client, self.config)
    
    def _should_retry_fanout(self, state: GraphState) -> str:
        """Decide whether to retry fanout generation."""
        verdict = state.get('fanout_guardrail_verdict', 'PASS')
        retry_count = state.get('fanout_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.fanout_max_retries:
            logger.info(f"Fanout Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.fanout_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.fanout_max_retries:
            logger.warning(f"Fanout Guardrail: {verdict} - max retries reached")
        
        return 'proceed'
    
    def _should_retry_copy(self, state: GraphState) -> str:
        """Decide whether to retry copy generation."""
        verdict = state.get('copy_guardrail_verdict', 'PASS')
        retry_count = state.get('copy_retry_count', 0)
        
        should_retry = verdict == 'FAIL' or (verdict == 'NEEDS_REVIEW' and self.retry_on_needs_review)
        
        if should_retry and retry_count < self.copy_max_retries:
            logger.info(f"Copy Guardrail: {verdict} - triggering retry {retry_count + 1}/{self.copy_max_retries}")
            return 'retry'
        
        if should_retry and retry_count >= self.copy_max_retries:
            logger.warning(f"Copy Guardrail: {verdict} - max retries reached")
        
        return 'end'
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph state graph."""
        workflow = StateGraph(GraphState)
        
        if self.mode == "v2":
            self._build_v2_graph(workflow)
        else:
            self._build_v1_graph(workflow)
        
        return workflow.compile()
    
    def _build_v1_graph(self, workflow: StateGraph):
        """Build V1 mode graph: Fanout -> [Guardrail] -> Copy -> [Guardrail]"""
        workflow.add_node("fanout_agent_v1", self.fanout_v1)
        workflow.add_node("copy_generator_agent", self.copy_generator)
        workflow.set_entry_point("fanout_agent_v1")
        
        if self.fanout_guardrail_enabled:
            workflow.add_node("fanout_guardrail_agent", self.fanout_guardrail)
            workflow.add_edge("fanout_agent_v1", "fanout_guardrail_agent")
            workflow.add_conditional_edges(
                "fanout_guardrail_agent",
                self._should_retry_fanout,
                {'retry': 'fanout_agent_v1', 'proceed': 'copy_generator_agent'}
            )
        else:
            workflow.add_edge("fanout_agent_v1", "copy_generator_agent")
        
        if self.copy_guardrail_enabled:
            workflow.add_node("copy_guardrail_agent", self.copy_guardrail)
            workflow.add_edge("copy_generator_agent", "copy_guardrail_agent")
            workflow.add_conditional_edges(
                "copy_guardrail_agent",
                self._should_retry_copy,
                {'retry': 'copy_generator_agent', 'end': END}
            )
        else:
            workflow.add_edge("copy_generator_agent", END)
    
    def _build_v2_graph(self, workflow: StateGraph):
        """Build V2 mode graph: Generate -> Filter -> [Guardrail] -> Copy -> [Guardrail]"""
        workflow.add_node("fanout_agent_v2_generate", self.fanout_v2_generate)
        workflow.add_node("fanout_agent_v2_filter", self.fanout_v2_filter)
        workflow.add_node("copy_generator_agent", self.copy_generator)
        
        workflow.set_entry_point("fanout_agent_v2_generate")
        workflow.add_edge("fanout_agent_v2_generate", "fanout_agent_v2_filter")
        
        if self.fanout_guardrail_enabled:
            workflow.add_node("fanout_guardrail_agent", self.fanout_guardrail)
            workflow.add_edge("fanout_agent_v2_filter", "fanout_guardrail_agent")
            workflow.add_conditional_edges(
                "fanout_guardrail_agent",
                self._should_retry_fanout,
                {'retry': 'fanout_agent_v2_generate', 'proceed': 'copy_generator_agent'}
            )
        else:
            workflow.add_edge("fanout_agent_v2_filter", "copy_generator_agent")
        
        if self.copy_guardrail_enabled:
            workflow.add_node("copy_guardrail_agent", self.copy_guardrail)
            workflow.add_edge("copy_generator_agent", "copy_guardrail_agent")
            workflow.add_conditional_edges(
                "copy_guardrail_agent",
                self._should_retry_copy,
                {'retry': 'copy_generator_agent', 'end': END}
            )
        else:
            workflow.add_edge("copy_generator_agent", END)

    def run(self, query: str, item_types: list = None) -> Dict[str, Any]:
        """Run the workflow."""
        logger.info("=" * 60)
        logger.info(f"Running workflow [{self.mode.upper()}] for: {query}")
        logger.info(f"Fanout guardrail: {'ENABLED' if self.fanout_guardrail_enabled else 'DISABLED'}")
        logger.info(f"Copy guardrail: {'ENABLED' if self.copy_guardrail_enabled else 'DISABLED'}")
        logger.info("=" * 60)
        
        initial_state = create_initial_state(query, item_types)
        final_state = self.graph.invoke(initial_state)
        
        return self._build_result(final_state)
    
    def _build_result(self, final_state: GraphState) -> Dict[str, Any]:
        """Build the result dictionary from final state."""
        total_time = (
            final_state.get('fanout_time', 0) + 
            final_state.get('copy_time', 0) +
            final_state.get('fanout_guardrail_time', 0) +
            final_state.get('copy_guardrail_time', 0)
        )
        
        validation_results = final_state.get('validation_results', [])
        avg_score = sum(v.get('score', 0) for v in validation_results) / len(validation_results) if validation_results else 0
        
        return {
            "query": final_state.get('query', ''),
            "fanout_output": final_state.get('fanout_output', {}),
            "final_copy": final_state.get('final_copy', ''),
            "fanout_time": final_state.get('fanout_time', 0),
            "copy_time": final_state.get('copy_time', 0),
            "fanout_guardrail_time": final_state.get('fanout_guardrail_time', 0),
            "copy_guardrail_time": final_state.get('copy_guardrail_time', 0),
            "total_time": total_time,
            "mode": self.mode,
            "fanout_guardrail_verdict": final_state.get('fanout_guardrail_verdict', 'NOT_RUN'),
            "fanout_retries": max(0, final_state.get('fanout_retry_count', 0) - 1),
            "copy_guardrail_verdict": final_state.get('copy_guardrail_verdict', 'NOT_RUN'),
            "copy_retries": max(0, final_state.get('copy_retry_count', 0) - 1),
            "validation": {"steps": validation_results, "overall_score": avg_score}
        }
