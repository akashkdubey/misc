
import yaml
import os
from pathlib import Path
from typing import Dict, Any

def load_config(config_path: str = None) -> Dict[str, Any]:
    """
    Load configuration from YAML file.
    
    Args:
        config_path: Path to the config file. Defaults to 'conf.yml' in project root.
        
    Returns:
        Dictionary containing configuration.
    """
    if config_path:
        path = Path(config_path)
    else:
        # Default to conf.yml in project root (parent of copy_gen package)
        path = Path(__file__).parent.parent / "conf.yml"
        
    if not path.exists():
        # Fallback for when running from different contexts (e.g. tests)
        candidate = Path("conf.yml")
        if candidate.exists():
            path = candidate
        else:
            raise FileNotFoundError(f"Configuration file not found: {path} or {candidate}")
            
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

class Strategies:
    """Constants for generation strategies."""
    V1 = "v1"
    V2 = "v2"
    ALL = [V1, V2]
