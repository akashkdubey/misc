
import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple

def setup_logging(log_dir: str = "logs", console_level: int = logging.INFO, file_level: int = logging.INFO) -> Tuple[Path, logging.FileHandler]:
    """
    Configure project-wide logging.
    
    Args:
        log_dir: Directory to save log files.
        console_level: Logging level for console output.
        file_level: Logging level for file output.
        
    Returns:
        Tuple[Path to log file, FileHandler instance]
    """
    root_log_path = Path(log_dir)
    root_log_path.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = root_log_path / f"copy_gen_{timestamp}.log"
    
    # Reset existing handlers to avoid duplication during re-runs or tests
    root_logger = logging.getLogger()
    root_logger.handlers = []
    root_logger.setLevel(min(console_level, file_level))
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    
    # File Handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(file_level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)
    
    # Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(console_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    logging.info(f"Logging initialized. File: {log_file}")
    
    return log_file, file_handler
