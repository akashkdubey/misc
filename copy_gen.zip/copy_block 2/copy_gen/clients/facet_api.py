import os
import requests
import json
import yaml
import logging
from pathlib import Path
from ..config import load_config

def get_authorization_token(config):
    """Get authorization token for Target API."""
    oauth_config = config['api'].get('oauth', {})

    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "grant_type": oauth_config.get('grant_type', 'password'),
        "username": oauth_config.get('username'),
        "password": oauth_config.get('password'),
        "scope": oauth_config.get('scope', '')
    }

    auth = (oauth_config.get('client_id'), oauth_config.get('client_secret'))

    # SSL verification (disable for internal APIs with self-signed certs)
    verify_ssl = oauth_config.get('verify_ssl', True)

    response = requests.post(oauth_config.get('token_url'), headers=headers, data=data, auth=auth, verify=verify_ssl)
    response.raise_for_status()

    return response.json().get("access_token")


def get_facets(keyword, config=None):
    """Get facets for a keyword from Target API.
    
    Args:
        keyword (str): Search keyword to get facets for
        config (dict, optional): Configuration dictionary. If None, loads from conf.yml
        
    Returns:
        dict: JSON response containing facets data
    """
    if config is None:
        config = load_config()
    
    facets_config = config['api'].get('facets', {})

    # Build headers: include x-api-key if configured. Also include Authorization if available
    headers = {}
    api_key = facets_config.get('api_key')
    if api_key:
        headers['x-api-key'] = api_key

    # Authorization token sources: environment BEARER_TOKEN, config.api.oauth.bearer_token, or OAuth flow
    auth_token = os.environ.get('BEARER_TOKEN')
    oauth_conf = config.get('api', {}).get('oauth', {})
    if not auth_token:
        auth_token = oauth_conf.get('bearer_token')
    if not auth_token and oauth_conf.get('token_url'):
        try:
            auth_token = get_authorization_token(config)
        except Exception:
            logging.debug("Unable to fetch OAuth token; proceeding without Authorization header.")

    if auth_token:
        headers['Authorization'] = f"Bearer {auth_token}"

    # Query parameters
    params = {"q": keyword}

    # SSL verification: prefer top-level `api.verify_ssl`, then facets-specific, default True
    verify_ssl = config.get('api', {}).get('verify_ssl', facets_config.get('verify_ssl', True))

    logging.debug(f"Requesting facets API with query: {keyword}")
    logging.debug(f"URL: {facets_config.get('url')}")
    logging.debug(f"Headers keys: {list(headers.keys())}")
    logging.debug(f"Params: {params}")

    # Make initial request (send both headers if present)
    response = requests.get(facets_config.get('url'), headers=headers, params=params, verify=verify_ssl)

    # If we get unauthorized and we had an Authorization header, retry without it and rely on x-api-key only
    if response.status_code in (401, 403) and 'Authorization' in headers:
        logging.warning("Facets API returned 401/403 with Authorization header; retrying without Authorization header.")
        headers.pop('Authorization', None)
        response = requests.get(facets_config.get('url'), headers=headers, params=params, verify=verify_ssl)

    response.raise_for_status()

    result = response.json()
    logging.debug(f"Facets API response status: {response.status_code}")
    logging.debug(f"Facets API response: {json.dumps(result, indent=2)}")

    return result


if __name__ == "__main__":
    # Example usage
    facets = get_facets("makeup")
    print(json.dumps(facets, indent=2))